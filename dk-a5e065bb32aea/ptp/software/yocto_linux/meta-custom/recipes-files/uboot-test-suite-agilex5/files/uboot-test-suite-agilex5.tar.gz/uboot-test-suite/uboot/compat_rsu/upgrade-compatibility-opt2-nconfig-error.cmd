# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_rsu/uboot/upgrade_compatibility_opt2_nconfig_error/test_steps.pl
echo "[uboot-upgrade-compatibility-opt2-nconfig-error] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] fatls mmc 0:1"
  fatls mmc 0:1
  echo "[cmd] iminfo"
  iminfo
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] sleep 5"
  sleep 5
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] rsu slot_enable 1"
  rsu slot_enable 1
  echo "[cmd] rsu slot_get_info 1"
  rsu slot_get_info 1
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] sf erase 0 +1000000"
  sf erase 0 +1000000
  echo "[PASS] Generated U-Boot command sequence completed"
fi
