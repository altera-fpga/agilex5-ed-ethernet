# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-i2c] Start I2C detect/read smoke test"

if test -z "${uboot_i2c_bus}"; then setenv uboot_i2c_bus 0; fi
if test -z "${uboot_i2c_addr}"; then setenv uboot_i2c_addr; fi
if test -z "${uboot_i2c_reg}"; then setenv uboot_i2c_reg 0x0; fi

i2c bus
i2c dev ${uboot_i2c_bus}
i2c probe
if test -n "${uboot_i2c_addr}"; then
  i2c md ${uboot_i2c_addr} ${uboot_i2c_reg} 1
fi

echo "[PASS] U-Boot I2C command sequence completed"
