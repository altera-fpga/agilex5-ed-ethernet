# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/fpga2hps_rw/test_steps.pl
echo "[uboot-fpga2hps-rw] Start generated command sequence"
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] md 0x0082000020 4"
md 0x0082000020 4
echo "[PASS] Generated U-Boot command sequence completed"
