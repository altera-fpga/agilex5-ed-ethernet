# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from qspi/uboot/qspi_access/test_steps.pl
echo "[uboot-qspi-access] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] sf erase 0x06000000 100000"
  sf erase 0x06000000 100000
  echo "[cmd] mw 0x10000 FACECAFE"
  mw 0x10000 FACECAFE
  echo "[cmd] md 0x10000 1"
  md 0x10000 1
  echo "[cmd] sf write 0x10000 0x06000000 4"
  sf write 0x10000 0x06000000 4
  echo "[cmd] sf read 0x20000 0x06000000 4"
  sf read 0x20000 0x06000000 4
  echo "[cmd] md 0x20000 1"
  md 0x20000 1
  echo "[cmd] reset"
  reset
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] sf read 0x30000 0x06000000 4"
  sf read 0x30000 0x06000000 4
  echo "[cmd] md 0x30000 1"
  md 0x30000 1
  echo "[PASS] Generated U-Boot command sequence completed"
fi
