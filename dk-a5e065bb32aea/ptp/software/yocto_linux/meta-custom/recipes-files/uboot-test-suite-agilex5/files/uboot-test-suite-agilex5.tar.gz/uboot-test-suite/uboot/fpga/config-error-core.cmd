# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_config/uboot/config_error_core/test_steps.pl
echo "[uboot-config-error-core] Start generated command sequence"
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] bridge disable"
bridge disable
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] setenv autoload no"
setenv autoload no
echo "[cmd] dhcp"
dhcp
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] bridge disable"
bridge disable
echo "[PASS] Generated U-Boot command sequence completed"
