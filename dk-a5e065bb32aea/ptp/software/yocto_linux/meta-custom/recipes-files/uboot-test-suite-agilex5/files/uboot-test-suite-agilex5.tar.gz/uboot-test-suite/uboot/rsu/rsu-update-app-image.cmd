# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_update_app_image/test_steps.pl
echo "[uboot-rsu-update-app-image] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  printenv
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu status_log"
  rsu status_log
  echo "[cmd] rsu slot_erase 3"
  rsu slot_erase 3
  echo "[cmd] rsu slot_enable 3"
  rsu slot_enable 3
  echo "[cmd] dcache off"
  dcache off
  echo "[PASS] Generated U-Boot command sequence completed"
fi
