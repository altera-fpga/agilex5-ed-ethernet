# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-usb-rw] Start USB storage read/write smoke test"

if test -z "${uboot_usb_dev}"; then setenv uboot_usb_dev 0; fi
if test -z "${uboot_usb_part}"; then setenv uboot_usb_part 1; fi
if test -z "${uboot_usb_test_file}"; then setenv uboot_usb_test_file testsuite_usb.txt; fi
if test -z "${uboot_pattern_addr}"; then setenv uboot_pattern_addr ${loadaddr}; fi
if test -z "${uboot_usb_pattern}"; then setenv uboot_usb_pattern 0x5a; fi
if test -z "${uboot_usb_size}"; then setenv uboot_usb_size 0x100; fi

usb reset
mw.b ${uboot_pattern_addr} ${uboot_usb_pattern} ${uboot_usb_size}
if fatwrite usb ${uboot_usb_dev}:${uboot_usb_part} ${uboot_pattern_addr} ${uboot_usb_test_file} ${uboot_usb_size}; then
  echo "[uboot-usb-rw] write OK"
else
  echo "[FAIL] USB fatwrite failed"
fi

if fatload usb ${uboot_usb_dev}:${uboot_usb_part} ${uboot_read_addr} ${uboot_usb_test_file}; then
  echo "[uboot-usb-rw] read OK"
else
  echo "[FAIL] USB fatload failed"
fi

if cmp.b ${uboot_pattern_addr} ${uboot_read_addr} ${uboot_usb_size}; then
  echo "[PASS] U-Boot USB read/write compare passed"
else
  echo "[FAIL] U-Boot USB read/write compare failed"
fi
