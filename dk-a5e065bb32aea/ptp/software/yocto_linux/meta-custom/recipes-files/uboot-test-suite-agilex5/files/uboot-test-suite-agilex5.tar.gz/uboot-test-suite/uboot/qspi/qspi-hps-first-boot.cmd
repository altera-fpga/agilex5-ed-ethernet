# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from qspi/uboot/qspi_hps_first_boot/test_steps.pl
echo "[uboot-qspi-hps-first-boot] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] sf read 1000000 420 10"
  sf read 1000000 420 10
  echo "[cmd] md 1000000 10"
  md 1000000 10
  echo "[cmd] version"
  version
  echo "[cmd] reset -w"
  reset -w
  echo "[cmd] setenv reset warm"
  setenv reset warm
  echo "[cmd] reset"
  reset
  echo "[cmd] setenv reset cold"
  setenv reset cold
  echo "[cmd] reset"
  reset
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] bridge enable"
  bridge enable
  echo "[cmd] md f9000000 1"
  md f9000000 1
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] md.l 0xff8d2000 1"
  md.l 0xff8d2000 1
  echo "[cmd] bridge enable"
  bridge enable
  echo "[cmd] md f9000000 1"
  md f9000000 1
  echo "[PASS] Generated U-Boot command sequence completed"
fi
