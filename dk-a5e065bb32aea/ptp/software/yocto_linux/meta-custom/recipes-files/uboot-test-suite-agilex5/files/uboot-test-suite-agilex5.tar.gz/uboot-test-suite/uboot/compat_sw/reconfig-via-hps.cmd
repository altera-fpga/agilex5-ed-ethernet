# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/reconfig_via_hps/test_steps.pl
echo "[uboot-reconfig-via-hps] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] fatls mmc 0:1"
  fatls mmc 0:1
  echo "[cmd] iminfo"
  iminfo
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] fatls mmc 0\:1"
  fatls mmc 0\:1
  echo "[cmd] bridge enable"
  bridge enable
  echo "[cmd] mw 80000000 aaaaaaaa"
  mw 80000000 aaaaaaaa
  echo "[cmd] md 80000000 1"
  md 80000000 1
  echo "[cmd] mw 8003ff00 deadbeef"
  mw 8003ff00 deadbeef
  echo "[cmd] md 8003ff00 1"
  md 8003ff00 1
  echo "[cmd] bridge disable"
  bridge disable
  echo "[PASS] Generated U-Boot command sequence completed"
fi
