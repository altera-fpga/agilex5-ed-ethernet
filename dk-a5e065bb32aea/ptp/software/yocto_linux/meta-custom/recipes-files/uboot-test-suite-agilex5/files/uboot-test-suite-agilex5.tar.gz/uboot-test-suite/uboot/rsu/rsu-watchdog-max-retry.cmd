# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_watchdog_max_retry/test_steps.pl
echo "[uboot-rsu-watchdog-max-retry] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[PASS] Generated U-Boot command sequence completed"
fi
