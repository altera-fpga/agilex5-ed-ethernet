# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_load_factory/test_steps.pl
echo "[uboot-rsu-load-factory] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu slot_load_factory"
  rsu slot_load_factory
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu check_running_factory"
  rsu check_running_factory
  echo "[PASS] Generated U-Boot command sequence completed"
fi
