# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_combined_application_image_update_viareset_lfs/test_steps.pl
echo "[uboot-rsu-combined-application-image-update-viareset-lfs] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  printenv
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] sf read 0xa0000000 0x200000 0x40"
  sf read 0xa0000000 0x200000 0x40
  echo "[cmd] md 0xa0000000 0x10"
  md 0xa0000000 0x10
  echo "[cmd] sf read 0xb0000000 0x1FA8 0x10"
  sf read 0xb0000000 0x1FA8 0x10
  echo "[cmd] md 0xb0000000 0x10"
  md 0xb0000000 0x10
  echo "[cmd] rsu slot_erase 1"
  rsu slot_erase 1
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] sf probe"
  sf probe
  echo "[cmd] sf read 0xa0000000 0x200000 0x40"
  sf read 0xa0000000 0x200000 0x40
  echo "[cmd] md 0xa0000000 0x10"
  md 0xa0000000 0x10
  echo "[cmd] sf read 0xb0000000 0x1FA8 0x10"
  sf read 0xb0000000 0x1FA8 0x10
  echo "[cmd] md 0xb0000000 0x10"
  md 0xb0000000 0x10
  echo "[PASS] Generated U-Boot command sequence completed"
fi
