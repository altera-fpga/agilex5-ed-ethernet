# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_ghrd/uboot/sof_compat/test_steps.pl
echo "[uboot-sof-compat] Start generated command sequence"
echo "[cmd] dhcp"
dhcp
echo "[cmd] dcache flush"
dcache flush
echo "[PASS] Generated U-Boot command sequence completed"
