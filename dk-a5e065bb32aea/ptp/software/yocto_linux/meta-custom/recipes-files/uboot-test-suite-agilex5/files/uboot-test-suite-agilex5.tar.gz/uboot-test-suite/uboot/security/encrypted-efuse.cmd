# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from security/uboot/encrypted_efuse/test_steps.pl
echo "[uboot-encrypted-efuse] Start generated command sequence"
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] bridge disable"
bridge disable
echo "[PASS] Generated U-Boot command sequence completed"
