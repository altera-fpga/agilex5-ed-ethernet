# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/read_pre_written_fpga_design/test_steps.pl
echo "[uboot-read-pre-written-fpga-design] Start generated command sequence"
echo "[cmd] echo simics:write_fpga_design_example"
echo simics:write_fpga_design_example
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] md 0x40000000 1"
md 0x40000000 1
echo "[cmd] md 0x400003fc 1"
md 0x400003fc 1
echo "[PASS] Generated U-Boot command sequence completed"
