# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from reset/uboot/jtag_cold_reset/test_steps.pl
echo "[uboot-jtag-cold-reset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] fatls mmc 0:1"
  fatls mmc 0:1
  echo "[cmd] bridge enable"
  bridge enable
  echo "[cmd] reset"
  reset
  echo "[PASS] Generated U-Boot command sequence completed"
fi
