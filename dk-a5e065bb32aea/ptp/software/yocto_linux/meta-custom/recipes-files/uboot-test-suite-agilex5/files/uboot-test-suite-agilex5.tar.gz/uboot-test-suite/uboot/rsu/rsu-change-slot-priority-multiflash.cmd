# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_change_slot_priority_multiflash/test_steps.pl
echo "[uboot-rsu-change-slot-priority-multiflash] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  printenv
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] fatrm mmc 0:1 u-boot.itb"
  fatrm mmc 0:1 u-boot.itb
  echo "[cmd] fatls mmc 0"
  fatls mmc 0
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu init"
  rsu init
  echo "[cmd] dcache off"
  dcache off
  echo "[PASS] Generated U-Boot command sequence completed"
fi
