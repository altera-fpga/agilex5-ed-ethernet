# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/rsu_reset_counter/test_steps.pl
echo "[uboot-rsu-reset-counter] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] fatls mmc 0:1"
  fatls mmc 0:1
  echo "[cmd] iminfo"
  iminfo
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] rsu notify 0x1234"
  rsu notify 0x1234
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] wdt dev watchdog\@10d00200"
  wdt dev watchdog\@10d00200
  echo "[cmd] wdt dev"
  wdt dev
  echo "[cmd] wdt start 200"
  wdt start 200
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[PASS] Generated U-Boot command sequence completed"
fi
