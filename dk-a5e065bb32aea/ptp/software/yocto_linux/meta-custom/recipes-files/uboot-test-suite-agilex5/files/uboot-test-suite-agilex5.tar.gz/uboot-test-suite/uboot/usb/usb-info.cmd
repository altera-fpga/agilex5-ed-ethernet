# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-usb-info] Start USB information test"

usb reset
usb tree
usb info
if test -n "${uboot_usb_dev}"; then
  part list usb ${uboot_usb_dev}
fi

echo "[PASS] U-Boot USB information command sequence completed"
