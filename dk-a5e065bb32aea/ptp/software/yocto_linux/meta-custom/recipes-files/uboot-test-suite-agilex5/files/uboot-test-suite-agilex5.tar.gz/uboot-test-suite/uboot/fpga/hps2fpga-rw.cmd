# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/hps2fpga_rw/test_steps.pl
echo "[uboot-hps2fpga-rw] Start generated command sequence"
echo "[cmd] bridge enable"
bridge enable
echo "[PASS] Generated U-Boot command sequence completed"
