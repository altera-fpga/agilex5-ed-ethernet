# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_bridge/uboot/fpga2sdram_rw/test_steps.pl
echo "[uboot-fpga2sdram-rw] Start generated command sequence"
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] dcache flush"
dcache flush
echo "[PASS] Generated U-Boot command sequence completed"
