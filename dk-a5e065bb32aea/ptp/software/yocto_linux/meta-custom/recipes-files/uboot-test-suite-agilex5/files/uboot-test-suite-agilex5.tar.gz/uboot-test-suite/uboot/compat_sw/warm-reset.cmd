# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/warm_reset/test_steps.pl
echo "[uboot-warm-reset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] mw 2000000 aaaaaaaa 1"
  mw 2000000 aaaaaaaa 1
  echo "[cmd] mw 8000000 aaaaaaaa 1"
  mw 8000000 aaaaaaaa 1
  echo "[cmd] version"
  version
  echo "[cmd] reset -w"
  reset -w
  echo "[cmd] setenv reset warm"
  setenv reset warm
  echo "[cmd] reset"
  reset
  echo "[cmd] md 2000000 4"
  md 2000000 4
  echo "[cmd] md 8000000 4"
  md 8000000 4
  echo "[PASS] Generated U-Boot command sequence completed"
fi
