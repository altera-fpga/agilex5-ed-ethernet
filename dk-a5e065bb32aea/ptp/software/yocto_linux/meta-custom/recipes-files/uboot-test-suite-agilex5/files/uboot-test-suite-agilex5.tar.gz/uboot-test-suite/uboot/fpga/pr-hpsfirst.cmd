# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from pr/uboot/pr_hpsfirst/test_steps.pl
echo "[uboot-pr-hpsfirst] Start generated command sequence"
echo "[cmd] bdinfo"
bdinfo
echo "[cmd] fdt resize"
fdt resize
echo "[cmd] echo delay"
echo delay
echo "[cmd] echo delay"
echo delay
echo "[cmd] echo delay"
echo delay
echo "[cmd] fdt list \/aliases"
fdt list \/aliases
echo "[cmd] echo delay"
echo delay
echo "[cmd] echo delay"
echo delay
echo "[cmd] dhcp"
dhcp
echo "[cmd] sleep 5"
sleep 5
echo "[cmd] echo delay"
echo delay
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] md f9000800 1; md f9000900 1"
md f9000800 1; md f9000900 1
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] pr start"
pr start
echo "[cmd] pr end"
pr end
echo "[cmd] md f9000800 1; md f9000900 1"
md f9000800 1; md f9000900 1
echo "[PASS] Generated U-Boot command sequence completed"
