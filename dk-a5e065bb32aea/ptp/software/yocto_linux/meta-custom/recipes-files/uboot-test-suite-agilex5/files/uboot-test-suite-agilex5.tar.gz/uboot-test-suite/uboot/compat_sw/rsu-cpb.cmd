# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/rsu_cpb/test_steps.pl
echo "[uboot-rsu-cpb] Start generated command sequence"
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] fatls mmc 0:1"
fatls mmc 0:1
echo "[cmd] iminfo"
iminfo
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] fatls mmc 0:1"
fatls mmc 0:1
echo "[cmd] rsu list"
rsu list
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] sf probe"
sf probe
echo "[cmd] rsu list"
rsu list
echo "[PASS] Generated U-Boot command sequence completed"
