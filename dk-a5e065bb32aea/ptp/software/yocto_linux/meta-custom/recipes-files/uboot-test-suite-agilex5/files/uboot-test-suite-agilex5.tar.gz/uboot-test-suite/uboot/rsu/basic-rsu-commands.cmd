# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/basic_rsu_commands/test_steps.pl
echo "[uboot-basic-rsu-commands] Start generated command sequence"
echo "[cmd] rsu list"
rsu list
echo "[PASS] Generated U-Boot command sequence completed"
