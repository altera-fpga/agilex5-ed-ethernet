# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from i3c/uboot/basic_i3c_rw/test_steps.pl
echo "[uboot-basic-i3c-rw] Start generated command sequence"
echo "[cmd] i3c list"
i3c list
echo "[cmd] i3c i3c\@10da1000"
i3c i3c\@10da1000
echo "[cmd] i3c current"
i3c current
echo "[cmd] i3c write 031E00 3 0"
i3c write 031E00 3 0
echo "[cmd] i3c write 03 1 0"
i3c write 03 1 0
echo "[cmd] i3c read 2 0"
i3c read 2 0
echo "[cmd] i3c write 020F00 3 0"
i3c write 020F00 3 0
echo "[cmd] i3c write 02 1 0"
i3c write 02 1 0
echo "[cmd] i3c read 2 0"
i3c read 2 0
echo "[PASS] Generated U-Boot command sequence completed"
