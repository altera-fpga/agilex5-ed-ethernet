# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-bridge] Start FPGA bridge enable/read test"

if test -z "${uboot_bridge_verify_addr}"; then setenv uboot_bridge_verify_addr 0xf9000000; fi

bridge enable
md.l ${uboot_bridge_verify_addr} 1

echo "[uboot-bridge] Check readback above. Expected pattern may be board/design specific."
echo "[PASS] U-Boot bridge command sequence completed"
