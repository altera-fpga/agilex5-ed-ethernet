# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_config/uboot/fpga_config_nconfig/test_steps.pl
echo "[uboot-fpga-config-nconfig] Start generated command sequence"
echo "[cmd] setenv autoload no"
setenv autoload no
echo "[cmd] dhcp"
dhcp
echo "[PASS] Generated U-Boot command sequence completed"
