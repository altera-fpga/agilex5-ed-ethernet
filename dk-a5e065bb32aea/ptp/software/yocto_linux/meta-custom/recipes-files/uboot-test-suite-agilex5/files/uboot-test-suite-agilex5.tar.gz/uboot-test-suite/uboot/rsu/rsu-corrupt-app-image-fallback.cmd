# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_corrupt_app_image_fallback/test_steps.pl
echo "[uboot-rsu-corrupt-app-image-fallback] Start generated command sequence"
echo "[cmd] dcache off"
dcache off
echo "[cmd] sf probe"
sf probe
echo "[cmd] rsu check_running_factory"
rsu check_running_factory
echo "[PASS] Generated U-Boot command sequence completed"
