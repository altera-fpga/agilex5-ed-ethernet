# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
echo "[uboot-gpio] Start GPIO toggle test"

if test -z "${uboot_gpio_pin1}"; then setenv uboot_gpio_pin1 portb13; fi
if test -z "${uboot_gpio_pin2}"; then setenv uboot_gpio_pin2 portb23; fi

gpio status -a

echo "[uboot-gpio] Testing ${uboot_gpio_pin1}"
gpio input ${uboot_gpio_pin1}
gpio set ${uboot_gpio_pin1}
gpio clear ${uboot_gpio_pin1}
gpio toggle ${uboot_gpio_pin1}

echo "[uboot-gpio] Testing ${uboot_gpio_pin2}"
gpio input ${uboot_gpio_pin2}
gpio set ${uboot_gpio_pin2}
gpio clear ${uboot_gpio_pin2}
gpio toggle ${uboot_gpio_pin2}

echo "[PASS] U-Boot GPIO command sequence completed"
