# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/max_retry_clear_counter/test_steps.pl
echo "[uboot-max-retry-clear-counter] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] rsu reset_retry_counter"
  rsu reset_retry_counter
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] rsu update 2000000"
  rsu update 2000000
  echo "[cmd] rsu list"
  rsu list
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] rsu list"
  rsu list
  echo "[PASS] Generated U-Boot command sequence completed"
fi
