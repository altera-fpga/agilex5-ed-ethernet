# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from security/uboot/signed_hps_first/test_steps.pl
echo "[uboot-signed-hps-first] Start generated command sequence"
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] bridge disable"
bridge disable
echo "[PASS] Generated U-Boot command sequence completed"
