#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
MKIMAGE_BIN="${MKIMAGE:-mkimage}"
command -v "$MKIMAGE_BIN" >/dev/null 2>&1 || { echo "mkimage not found. Install u-boot-tools or set MKIMAGE=/path/to/mkimage." >&2; exit 1; }

if [[ -f "$ROOT_DIR/config/uboot.env" ]]; then
  "$MKIMAGE_BIN" -A arm64 -T script -C none -n "test-suite config" -d "$ROOT_DIR/config/uboot.env" "$ROOT_DIR/config/uboot.scr"
  echo "Generated config/uboot.scr"
fi

find "$SCRIPT_DIR" -name '*.cmd' -type f | sort | while read -r cmd; do
  scr="${cmd%.cmd}.scr"
  name="$(basename "$cmd" .cmd)"
  "$MKIMAGE_BIN" -A arm64 -T script -C none -n "test-suite $name" -d "$cmd" "$scr"
  echo "Generated ${scr#$ROOT_DIR/}"
done
