# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from fpga_config/uboot/fpga_reconfig_stress/test_steps.pl
echo "[uboot-fpga-reconfig-stress] Start generated command sequence"
echo "[cmd] bridge disable"
bridge disable
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] bridge disable"
bridge disable
echo "[PASS] Generated U-Boot command sequence completed"
