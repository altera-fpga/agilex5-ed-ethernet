# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/watchdog_wreset/test_steps.pl
echo "[uboot-watchdog-wreset] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] mw 2000000 aaaaaaaa 1"
  mw 2000000 aaaaaaaa 1
  echo "[cmd] mw 8000000 aaaaaaaa 1"
  mw 8000000 aaaaaaaa 1
  echo "[cmd] dcache flush"
  dcache flush
  echo "[cmd] wdt dev watchdog\@10d00200"
  wdt dev watchdog\@10d00200
  echo "[cmd] wdt dev"
  wdt dev
  echo "[cmd] wdt start 200"
  wdt start 200
  echo "[cmd] mw.l 0xffd00204 0x11"
  mw.l 0xffd00204 0x11
  echo "[cmd] mw ffd00200 1"
  mw ffd00200 1
  echo "[cmd] md 2000000 4"
  md 2000000 4
  echo "[cmd] md 8000000 4"
  md 8000000 4
  echo "[PASS] Generated U-Boot command sequence completed"
fi
