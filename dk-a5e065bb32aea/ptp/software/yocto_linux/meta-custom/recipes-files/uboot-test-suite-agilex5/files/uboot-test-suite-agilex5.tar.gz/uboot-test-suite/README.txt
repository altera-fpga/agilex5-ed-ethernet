emb-test-suite U-Boot test-suite package

This package is for U-Boot prompt execution only.
It contains customer-editable U-Boot defaults and prebuilt U-Boot script images.

Package layout:
  config/uboot.env                     Editable U-Boot default variables
  config/uboot.scr                     Prebuilt U-Boot config script
  uboot/<category>/<test>.cmd          Source U-Boot command script
  uboot/<category>/<test>.scr          Prebuilt U-Boot script image
  uboot_manifest.tsv                   Packaged U-Boot script metadata
  metadata.env                         Package build metadata

TFTP example:
  setenv serverip <host-server-ip>
  dhcp
  tftp ${scriptaddr} uboot-test-suite/config/uboot.scr
  source ${scriptaddr}
  tftp ${scriptaddr} uboot-test-suite/uboot/ethernet/ping.scr
  source ${scriptaddr}

FAT/MMC example:
  load mmc 0:1 ${scriptaddr} uboot-test-suite/config/uboot.scr
  source ${scriptaddr}
  load mmc 0:1 ${scriptaddr} uboot-test-suite/uboot/ethernet/ping.scr
  source ${scriptaddr}
