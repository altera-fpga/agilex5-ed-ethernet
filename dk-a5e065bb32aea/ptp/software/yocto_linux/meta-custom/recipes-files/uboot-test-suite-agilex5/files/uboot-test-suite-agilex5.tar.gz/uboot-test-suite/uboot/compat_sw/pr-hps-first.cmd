# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from compat_sw/uboot/pr_hps_first/test_steps.pl
echo "[uboot-pr-hps-first] Start generated command sequence"
echo "[cmd] printenv"
printenv
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] fatls mmc 0:1"
fatls mmc 0:1
echo "[cmd] iminfo"
iminfo
echo "[cmd] version"
version
echo "[cmd] bdinfo"
bdinfo
echo "[cmd] version"
version
echo "[cmd] fdt resize"
fdt resize
echo "[cmd] echo delay"
echo delay
echo "[cmd] echo delay"
echo delay
echo "[cmd] echo delay"
echo delay
echo "[cmd] fdt list \/aliases"
fdt list \/aliases
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] sleep 5"
sleep 5
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] print filesize"
print filesize
echo "[cmd] dcache flush"
dcache flush
echo "[cmd] print filesize"
print filesize
echo "[cmd] md 0xFFD120DC 1"
md 0xFFD120DC 1
echo "[cmd] bridge enable"
bridge enable
echo "[cmd] md f9000800 1; md f9000900 1"
md f9000800 1; md f9000900 1
echo "[cmd] pr start"
pr start
echo "[cmd] pr end"
pr end
echo "[cmd] sleep 2"
sleep 2
echo "[cmd] md f9000800 1; md f9000900 1"
md f9000800 1; md f9000900 1
echo "[cmd] sleep 2"
sleep 2
echo "[cmd] md f9000800 1; md f9000900 1"
md f9000800 1; md f9000900 1
echo "[PASS] Generated U-Boot command sequence completed"
