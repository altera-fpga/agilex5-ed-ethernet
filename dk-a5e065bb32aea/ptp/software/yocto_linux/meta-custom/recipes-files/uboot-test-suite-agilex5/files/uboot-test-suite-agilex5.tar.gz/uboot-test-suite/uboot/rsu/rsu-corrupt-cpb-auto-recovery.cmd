# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_corrupt_cpb_auto_recovery/test_steps.pl
echo "[uboot-rsu-corrupt-cpb-auto-recovery] Start generated command sequence"
echo "[cmd] setenv autoload no"
setenv autoload no
echo "[cmd] printenv"
printenv
echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
setenv ethaddr 00:df:00:33:56:00
echo "[cmd] dhcp"
dhcp
echo "[cmd] dcache off"
dcache off
echo "[PASS] Generated U-Boot command sequence completed"
