# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_combined_application_image_update/test_steps.pl
echo "[uboot-rsu-combined-application-image-update] Start generated command sequence"
if test "${uboot_allow_destructive}" != "1"; then
  echo "[SKIP] Destructive/reset/reconfiguration U-Boot flow not armed. Set uboot_allow_destructive=1 to run."
else
  echo "[cmd] setenv autoload no"
  setenv autoload no
  echo "[cmd] printenv"
  printenv
  echo "[cmd] setenv ethaddr 00:df:00:33:56:00"
  setenv ethaddr 00:df:00:33:56:00
  echo "[cmd] dhcp"
  dhcp
  echo "[cmd] rsu display_dcmf_version"
  rsu display_dcmf_version
  echo "[cmd] rsu slot_erase 2"
  rsu slot_erase 2
  echo "[cmd] rsu slot_get_info 2"
  rsu slot_get_info 2
  echo "[cmd] rsu slot_load 2"
  rsu slot_load 2
  echo "[cmd] dcache off"
  dcache off
  echo "[cmd] rsu display_dcmf_version"
  rsu display_dcmf_version
  echo "[PASS] Generated U-Boot command sequence completed"
fi
