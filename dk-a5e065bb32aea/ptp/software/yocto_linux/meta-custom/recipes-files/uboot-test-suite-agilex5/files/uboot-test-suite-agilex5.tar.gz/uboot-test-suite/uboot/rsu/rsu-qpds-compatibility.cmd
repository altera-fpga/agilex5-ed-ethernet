# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from rsu/uboot/rsu_qpds_compatibility/test_steps.pl
echo "[uboot-rsu-qpds-compatibility] Start generated command sequence"
echo "[cmd] dcache off"
dcache off
echo "[cmd] rsu list"
rsu list
echo "[PASS] Generated U-Boot command sequence completed"
