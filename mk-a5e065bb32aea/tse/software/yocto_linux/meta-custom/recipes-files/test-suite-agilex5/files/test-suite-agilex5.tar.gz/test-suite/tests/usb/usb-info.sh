#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Display USB topology and storage enumeration."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  USB_REQUIRE_STORAGE=0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${USB_REQUIRE_STORAGE:=0}"
log()  { echo "[usb-info] $*"; }
fail() { echo "[usb-info] FAIL: $*" >&2; exit 1; }

log "USB devices"
if command -v lsusb >/dev/null 2>&1; then
  lsusb
  lsusb -t || true
else
  find /sys/bus/usb/devices -maxdepth 2 -type d | sort
fi

log "Block devices"
lsblk -o NAME,TRAN,SIZE,TYPE,FSTYPE,MOUNTPOINTS || true

if [[ "$USB_REQUIRE_STORAGE" == "1" ]] && ! lsblk -S | grep -qi usb; then
  fail "USB storage device not detected"
fi

log "PASS: USB enumeration completed"
