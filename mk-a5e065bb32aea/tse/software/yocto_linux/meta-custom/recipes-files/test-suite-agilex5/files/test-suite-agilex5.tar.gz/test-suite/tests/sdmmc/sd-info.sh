#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="List SD/MMC block devices and perform a safe read-only mount smoke test."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [block-device]

Environment:
  SDMMC_DEV=/dev/mmcblk0
  SDMMC_PARTITION=/dev/mmcblk0p1
  SDMMC_MOUNT_RW=0

Notes:
  - Default mode is read-only. Set SDMMC_MOUNT_RW=1 only when a write test is intended.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${SDMMC_DEV:=/dev/mmcblk0}"
: "${SDMMC_PARTITION:=${SDMMC_DEV}p1}"
: "${SDMMC_MOUNT_RW:=0}"

DEV="${1:-$SDMMC_DEV}"
PART="${SDMMC_PARTITION}"

log()  { echo "[sd-info] $*"; }
fail() { echo "[sd-info] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

need lsblk
need mount
need umount

[[ -b "$DEV" ]] || fail "block device not found: $DEV"

log "Detected block devices"
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS

if [[ ! -b "$PART" ]]; then
  log "Partition $PART not found; read-only device enumeration completed"
  exit 0
fi

MNT="$(mktemp -d /tmp/sd-info.XXXXXX)"
cleanup() { mountpoint -q "$MNT" && umount "$MNT" || true; rmdir "$MNT" 2>/dev/null || true; }
trap cleanup EXIT

if [[ "$SDMMC_MOUNT_RW" == "1" ]]; then
  log "Mounting $PART read-write"
  mount "$PART" "$MNT"
  touch "$MNT/testsuite_sdmmc_rw_check" || fail "failed to create write-check file"
  rm -f "$MNT/testsuite_sdmmc_rw_check"
else
  log "Mounting $PART read-only"
  mount -o ro "$PART" "$MNT"
fi

log "Mounted content sample"
find "$MNT" -maxdepth 2 -mindepth 1 | head -40 || true
log "PASS: SD/MMC information check completed"
