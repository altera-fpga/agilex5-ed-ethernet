#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
# Auto-generated test-suite wrapper from pr/linux/pr_persona_selfbuild_switch/test_steps.pl
set -euo pipefail

DESCRIPTION="Run on-board command sequence ported from pr/linux/pr_persona_selfbuild_switch/test_steps.pl."
usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [--yes]

This is an on-board test-suite shell wrapper generated from the original regtest
pr/linux/pr_persona_selfbuild_switch/test_steps.pl. It executes the literal target-side command sequence that can run on
Linux without PeRT/ARC/telnet orchestration. Board-specific resources, host-side
programming steps, and telnet wait patterns are intentionally not embedded.

Environment:
  TESTSUITE_ALLOW_DESTRUCTIVE=1  Required for reset/flash/partition/reconfig flows.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi
CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

log()  { echo "[pr-persona-selfbuild-switch] $*"; }
fail() { echo "[pr-persona-selfbuild-switch] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then fail "this test requires root privileges"; fi

need 'ls'
need 'cp'
need 'dtbt'
need 'find'
need 'cat'

WORKDIR="$(mktemp -d /tmp/testsuite-generated.XXXXXX)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

if [[ -n "${TESTSUITE_ASSETS_DIR:-}" && -d "$TESTSUITE_ASSETS_DIR" ]]; then
  while IFS= read -r asset; do
    cp "$asset" "$WORKDIR/" || true
  done < <(find "$TESTSUITE_ASSETS_DIR" -maxdepth 3 -type f 2>/dev/null)
  chmod +x "$WORKDIR"/* 2>/dev/null || true
fi

cat > "$WORKDIR/original_commands.sh" <<'TESTSUITE_ORIGINAL_COMMANDS'
ls
cp -f /home/root/persona0.rbf /lib/firmware
cp -f /home/root/persona1.rbf /lib/firmware
ls -la /boot/devicetree
ls -la /lib/firmware
dtbt -l
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000800.sysid/sysid/id
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000900.sysid/sysid/id
dtbt -l
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000800.sysid/sysid/id
find / -name sysid
cat /sys/bus/platform/drivers/altera_sysid/f9000900.sysid/sysid/id
TESTSUITE_ORIGINAL_COMMANDS

log "Executing generated command sequence from original regtest"
cd "$WORKDIR"
bash -eux "$WORKDIR/original_commands.sh"
log "PASS: generated command sequence completed"
