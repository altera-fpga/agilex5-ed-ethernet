#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Inspect clocksource/clockevent status and verify monotonic time progresses."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  TICK_SAMPLE_SEC=3
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${TICK_SAMPLE_SEC:=3}"
log()  { echo "[tick-check] $*"; }
fail() { echo "[tick-check] FAIL: $*" >&2; exit 1; }

log "Clocksource"
cat /sys/devices/system/clocksource/clocksource0/current_clocksource 2>/dev/null || true
cat /sys/devices/system/clocksource/clocksource0/available_clocksource 2>/dev/null || true

START="$(cut -d' ' -f1 /proc/uptime)"
sleep "$TICK_SAMPLE_SEC"
END="$(cut -d' ' -f1 /proc/uptime)"

awk -v start="$START" -v end="$END" -v expected="$TICK_SAMPLE_SEC" '
BEGIN {
  delta = end - start;
  printf("[tick-check] uptime delta %.3f sec\n", delta);
  if (delta < expected - 0.5 || delta > expected + 0.5) exit 1;
}' || fail "monotonic tick delta outside expected range"

log "PASS: tick/clocksource check completed"
