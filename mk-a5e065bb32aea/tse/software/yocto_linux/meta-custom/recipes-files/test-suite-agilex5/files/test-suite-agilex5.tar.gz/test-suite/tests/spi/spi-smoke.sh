#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run SPI device discovery and optional spidev loopback/read-write smoke test."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [spidev]

Environment:
  SPI_DEV=/dev/spidev1.0
  SPI_LOOPBACK=0
  SPI_PAYLOAD_HEX=deadbeef

Notes:
  - Default mode is discovery-only to avoid assuming an external SPI EEPROM wiring.
  - Set SPI_LOOPBACK=1 when MOSI/MISO loopback or a compatible test peripheral is available.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${SPI_DEV:=/dev/spidev1.0}"
: "${SPI_LOOPBACK:=0}"
: "${SPI_PAYLOAD_HEX:=deadbeef}"
DEV="${1:-$SPI_DEV}"

log()  { echo "[spi-test] $*"; }
fail() { echo "[spi-test] FAIL: $*" >&2; exit 1; }

log "SPI devices"
ls -l /dev/spidev* 2>/dev/null || fail "no /dev/spidev* device found"

if [[ "$SPI_LOOPBACK" != "1" ]]; then
  log "PASS: SPI device discovery completed. Set SPI_LOOPBACK=1 for transfer test."
  exit 0
fi

command -v spidev_test >/dev/null 2>&1 || fail "spidev_test not found"
[[ -e "$DEV" ]] || fail "SPI device not found: $DEV"

log "Running spidev_test on $DEV"
spidev_test -D "$DEV" -v -p "$SPI_PAYLOAD_HEX"
log "PASS: SPI loopback/read-write command completed"
