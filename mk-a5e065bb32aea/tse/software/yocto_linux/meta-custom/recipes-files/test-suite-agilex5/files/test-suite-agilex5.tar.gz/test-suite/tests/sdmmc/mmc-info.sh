#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Display MMC/eMMC device, partition, and CID/CSD information."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [block-device]

Environment:
  MMC_DEV=/dev/mmcblk0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${MMC_DEV:=/dev/mmcblk0}"
DEV="${1:-$MMC_DEV}"
BASENAME="$(basename "$DEV")"
SYS="/sys/block/$BASENAME/device"

log()  { echo "[mmc-info] $*"; }
fail() { echo "[mmc-info] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

need lsblk
[[ -b "$DEV" ]] || fail "block device not found: $DEV"

log "Block layout"
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS "$DEV"

if [[ -d "$SYS" ]]; then
  for f in name type cid csd date fwrev hwrev manfid oemid serial; do
    [[ -r "$SYS/$f" ]] && printf '%-10s: %s\n' "$f" "$(cat "$SYS/$f")"
  done
else
  log "No MMC sysfs detail node found at $SYS"
fi

log "PASS: MMC/eMMC information check completed"
