#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Verify Linux sleep duration against a configurable tolerance."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [seconds]

Environment:
  TIMER_SLEEP_SEC=5
  TIMER_TOLERANCE_MS=500
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${TIMER_SLEEP_SEC:=5}"
: "${TIMER_TOLERANCE_MS:=500}"
SLEEP_SEC="${1:-$TIMER_SLEEP_SEC}"

log()  { echo "[sleep-timer] $*"; }
fail() { echo "[sleep-timer] FAIL: $*" >&2; exit 1; }

START_NS="$(date +%s%N)"
sleep "$SLEEP_SEC"
END_NS="$(date +%s%N)"
ELAPSED_MS=$(( (END_NS - START_NS) / 1000000 ))
EXPECTED_MS=$(( SLEEP_SEC * 1000 ))
LOW=$(( EXPECTED_MS - TIMER_TOLERANCE_MS ))
HIGH=$(( EXPECTED_MS + TIMER_TOLERANCE_MS ))

log "Expected ${EXPECTED_MS} ms, measured ${ELAPSED_MS} ms, tolerance ±${TIMER_TOLERANCE_MS} ms"
if [[ "$ELAPSED_MS" -lt "$LOW" || "$ELAPSED_MS" -gt "$HIGH" ]]; then
  fail "sleep duration outside tolerance"
fi
log "PASS: timer sleep duration is within tolerance"
