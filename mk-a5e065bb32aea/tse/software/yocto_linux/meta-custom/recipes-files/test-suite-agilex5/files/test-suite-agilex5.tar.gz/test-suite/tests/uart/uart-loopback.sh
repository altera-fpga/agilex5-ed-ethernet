#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run an optional UART loopback test using a configured tty device."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [tty-device]

Environment:
  UART_DEV=/dev/ttyS1
  UART_BAUD=115200
  UART_LOOPBACK=0

Notes:
  - Default mode lists tty devices only.
  - Set UART_LOOPBACK=1 when TX/RX loopback wiring is connected.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${UART_DEV:=/dev/ttyS1}"
: "${UART_BAUD:=115200}"
: "${UART_LOOPBACK:=0}"
DEV="${1:-$UART_DEV}"

log()  { echo "[uart-loopback] $*"; }
fail() { echo "[uart-loopback] FAIL: $*" >&2; exit 1; }

log "Available ttyS/ttyAMA devices"
ls -l /dev/ttyS* /dev/ttyAMA* 2>/dev/null || true

if [[ "$UART_LOOPBACK" != "1" ]]; then
  log "PASS: UART discovery completed. Set UART_LOOPBACK=1 for loopback transfer."
  exit 0
fi

[[ -c "$DEV" ]] || fail "UART device not found: $DEV"
command -v stty >/dev/null 2>&1 || fail "stty not found"
command -v timeout >/dev/null 2>&1 || fail "timeout not found"

PAYLOAD="testsuite-uart-$RANDOM"
stty -F "$DEV" "$UART_BAUD" raw -echo -crtscts || fail "failed to configure $DEV"
TMP="$(mktemp /tmp/uart-loopback.XXXXXX)"
trap 'rm -f "$TMP"' EXIT

timeout 3 cat "$DEV" > "$TMP" &
CAT_PID=$!
sleep 0.2
printf '%s' "$PAYLOAD" > "$DEV"
sleep 0.5
kill "$CAT_PID" 2>/dev/null || true
wait "$CAT_PID" 2>/dev/null || true

if grep -q "$PAYLOAD" "$TMP"; then
  log "PASS: UART loopback payload received"
else
  fail "loopback payload not received"
fi
