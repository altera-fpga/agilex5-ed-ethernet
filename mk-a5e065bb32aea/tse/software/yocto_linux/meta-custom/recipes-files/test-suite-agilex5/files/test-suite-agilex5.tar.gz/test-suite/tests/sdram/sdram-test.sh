#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run a configurable Linux memory smoke or bandwidth test."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [size]

Environment:
  MEMTEST_SIZE=64M
  MEMTEST_LOOPS=1
  MEMTEST_MODE=auto      # auto|memtester|dd

Examples:
  MEMTEST_SIZE=128M MEMTEST_LOOPS=2 test_steps.sh
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${MEMTEST_SIZE:=64M}"
: "${MEMTEST_LOOPS:=1}"
: "${MEMTEST_MODE:=auto}"
SIZE="${1:-$MEMTEST_SIZE}"

log()  { echo "[sdram-test] $*"; }
fail() { echo "[sdram-test] FAIL: $*" >&2; exit 1; }

log "Memory summary"
free -h || true

if [[ "$MEMTEST_MODE" != "dd" ]] && command -v memtester >/dev/null 2>&1; then
  log "Running memtester $SIZE $MEMTEST_LOOPS"
  memtester "$SIZE" "$MEMTEST_LOOPS"
else
  command -v dd >/dev/null 2>&1 || fail "dd not found"
  command -v awk >/dev/null 2>&1 || fail "awk not found"
  TEST_DIR="/dev/shm"
  [[ -d "$TEST_DIR" ]] || TEST_DIR="/tmp"
  TMPFILE="$(mktemp "$TEST_DIR/sdram-test.XXXXXX")"
  trap 'rm -f "$TMPFILE"' EXIT
  COUNT_MB="${SDRAM_DD_MB:-128}"
  log "Running dd RAM-backed write/read test (${COUNT_MB} MiB)"
  dd if=/dev/zero of="$TMPFILE" bs=1M count="$COUNT_MB" conv=fsync status=progress
  dd if="$TMPFILE" of=/dev/null bs=1M status=progress
fi

log "PASS: memory test completed"
