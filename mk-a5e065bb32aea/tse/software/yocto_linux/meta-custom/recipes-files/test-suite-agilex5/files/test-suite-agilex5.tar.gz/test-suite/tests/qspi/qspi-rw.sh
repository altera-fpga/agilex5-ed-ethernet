#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Erase/write/read/compare an MTD NOR region. Destructive; requires explicit opt-in."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [--yes] [mtd-dev] [offset] [size]

Environment:
  QSPI_MTD_DEV=/dev/mtd0
  QSPI_RW_OFFSET=0x06000000
  QSPI_RW_SIZE=0x10000
  QSPI_ERASE_SIZE=0x10000
  QSPI_PATTERN_FILE=<file>
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Examples:
  TESTSUITE_ALLOW_DESTRUCTIVE=1 test_steps.sh --yes /dev/mtd0 0x06000000 0x10000

Notes:
  - This test erases flash. Choose an unused, board-approved offset.
  - The default offset intentionally points away from common boot regions, but must still be reviewed per board image layout.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

CONFIRMED=0
if [[ "${1:-}" == "--yes" ]]; then CONFIRMED=1; shift; fi

: "${QSPI_MTD_DEV:=/dev/mtd0}"
: "${QSPI_RW_OFFSET:=0x06000000}"
: "${QSPI_RW_SIZE:=0x10000}"
: "${QSPI_ERASE_SIZE:=$QSPI_RW_SIZE}"

MTD_DEV="${1:-$QSPI_MTD_DEV}"
OFFSET="${2:-$QSPI_RW_OFFSET}"
SIZE="${3:-$QSPI_RW_SIZE}"
ERASE_SIZE="${QSPI_ERASE_SIZE}"

log()  { echo "[qspi-rw] $*"; }
fail() { echo "[qspi-rw] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  fail "must run as root because this test accesses MTD flash"
fi

if [[ "$CONFIRMED" -ne 1 && "${TESTSUITE_ALLOW_DESTRUCTIVE:-0}" != "1" ]]; then
  fail "destructive flash test not armed. Re-run with --yes or TESTSUITE_ALLOW_DESTRUCTIVE=1 after confirming the offset is safe."
fi

need dd
need cmp
need md5sum
need hexdump
need mtd_debug

[[ -c "$MTD_DEV" || -e "$MTD_DEV" ]] || fail "MTD device not found: $MTD_DEV"

WORKDIR="$(mktemp -d /tmp/qspi-rw.XXXXXX)"
cleanup() { rm -rf "$WORKDIR"; }
trap cleanup EXIT

SRC="$WORKDIR/write.bin"
DST="$WORKDIR/read.bin"

log "Device      : $MTD_DEV"
log "Offset      : $OFFSET"
log "Size        : $SIZE"
log "Erase size  : $ERASE_SIZE"

cat /proc/mtd || true
dmesg | grep -iE 'spi-nor|cadence|qspi|mtd' | tail -30 || true

if [[ -n "${QSPI_PATTERN_FILE:-}" ]]; then
  [[ -f "$QSPI_PATTERN_FILE" ]] || fail "QSPI_PATTERN_FILE not found: $QSPI_PATTERN_FILE"
  dd if="$QSPI_PATTERN_FILE" of="$SRC" bs=1 count=$((SIZE)) status=none
else
  dd if=/dev/urandom of="$SRC" bs=1 count=$((SIZE)) status=none
fi

log "Erasing flash region"
mtd_debug erase "$MTD_DEV" "$OFFSET" "$ERASE_SIZE"

log "Writing pattern"
mtd_debug write "$MTD_DEV" "$OFFSET" "$SIZE" "$SRC"

log "Reading back"
mtd_debug read "$MTD_DEV" "$OFFSET" "$SIZE" "$DST"

log "Checksums"
md5sum "$SRC" "$DST"

if cmp -s "$SRC" "$DST"; then
  log "PASS: readback matches written image"
else
  echo "---------- expected ----------"
  hexdump -C "$SRC" | head
  echo "---------- actual ------------"
  hexdump -C "$DST" | head
  fail "readback mismatch"
fi
