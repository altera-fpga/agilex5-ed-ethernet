#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run a lightweight out-of-box system information check."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

log() { echo "[syscheck] $*"; }
log "Kernel"
uname -a
log "CPU"
grep -E 'model name|Hardware|Processor|BogoMIPS' /proc/cpuinfo | head -20 || true
log "Memory"
free -h || true
log "Block devices"
lsblk || true
log "Network"
ip addr || true
log "PASS: system check completed"
