#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run optional USB storage read/write smoke test. Destructive only when explicitly armed."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [partition]

Environment:
  USB_PARTITION=/dev/sda1
  USB_MOUNT_RW=0
  TESTSUITE_ALLOW_DESTRUCTIVE=1

Notes:
  - Default mode mounts read-only and lists content.
  - Set USB_MOUNT_RW=1 and TESTSUITE_ALLOW_DESTRUCTIVE=1 to create/remove a test file.
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${USB_PARTITION:=/dev/sda1}"
: "${USB_MOUNT_RW:=0}"
PART="${1:-$USB_PARTITION}"

log()  { echo "[usb-rw] $*"; }
fail() { echo "[usb-rw] FAIL: $*" >&2; exit 1; }

[[ -b "$PART" ]] || fail "USB partition not found: $PART"
MNT="$(mktemp -d /tmp/usb-rw.XXXXXX)"
cleanup() { mountpoint -q "$MNT" && umount "$MNT" || true; rmdir "$MNT" 2>/dev/null || true; }
trap cleanup EXIT

if [[ "$USB_MOUNT_RW" == "1" ]]; then
  [[ "${TESTSUITE_ALLOW_DESTRUCTIVE:-0}" == "1" ]] || fail "write test not armed. Set TESTSUITE_ALLOW_DESTRUCTIVE=1."
  mount "$PART" "$MNT"
  echo "test-suite usb rw $(date -u +%FT%TZ)" > "$MNT/testsuite_usb_rw.txt"
  sync
  cat "$MNT/testsuite_usb_rw.txt"
  rm -f "$MNT/testsuite_usb_rw.txt"
else
  mount -o ro "$PART" "$MNT"
  find "$MNT" -maxdepth 2 -mindepth 1 | head -40 || true
fi

log "PASS: USB storage check completed"
