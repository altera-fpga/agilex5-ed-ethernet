#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run a Linux crypto user-space smoke test using OpenSSL encrypt/decrypt."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  CRYPTO_CIPHER=aes-256-cbc
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${CRYPTO_CIPHER:=aes-256-cbc}"
log()  { echo "[crypto-smoke] $*"; }
fail() { echo "[crypto-smoke] FAIL: $*" >&2; exit 1; }
command -v openssl >/dev/null 2>&1 || fail "openssl not found"

WORKDIR="$(mktemp -d /tmp/crypto-smoke.XXXXXX)"
trap 'rm -rf "$WORKDIR"' EXIT
printf 'Altera test-suite crypto smoke %s\n' "$(date -u +%FT%TZ)" > "$WORKDIR/plain.txt"

openssl enc -"$CRYPTO_CIPHER" -pbkdf2 -salt -pass pass:test-suite -in "$WORKDIR/plain.txt" -out "$WORKDIR/cipher.bin"
openssl enc -d -"$CRYPTO_CIPHER" -pbkdf2 -pass pass:test-suite -in "$WORKDIR/cipher.bin" -out "$WORKDIR/decrypted.txt"
cmp -s "$WORKDIR/plain.txt" "$WORKDIR/decrypted.txt" || fail "decrypted content mismatch"
log "PASS: OpenSSL $CRYPTO_CIPHER encrypt/decrypt completed"
