#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Read system manager HWMON temperature and voltage nodes."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [hwmon-path]

Environment:
  HWMON_PATH=/sys/class/hwmon/hwmon1
  HWMON_REQUIRE_ALL=0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${HWMON_PATH:=/sys/class/hwmon/hwmon1}"
: "${HWMON_REQUIRE_ALL:=0}"
PATH_ARG="${1:-$HWMON_PATH}"

log()  { echo "[hwmon] $*"; }
fail() { echo "[hwmon] FAIL: $*" >&2; exit 1; }

[[ -d "$PATH_ARG" ]] || fail "hwmon path not found: $PATH_ARG"

found=0
for node in "$PATH_ARG"/temp*_input "$PATH_ARG"/in*_input; do
  [[ -r "$node" ]] || continue
  found=1
  value="$(cat "$node")"
  printf '%-40s %s\n' "$(basename "$node")" "$value"
  if [[ "$HWMON_REQUIRE_ALL" == "1" && ! "$value" =~ ^-?[0-9]+$ ]]; then
    fail "non-numeric HWMON value in $node"
  fi
done

[[ "$found" -eq 1 ]] || fail "no readable temp*_input or in*_input nodes found"
log "PASS: HWMON read completed"
