#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run I2C bus detection and optional register read/write smoke test."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh [bus] [addr]

Environment:
  I2C_BUS=0
  I2C_ADDR=0x50
  I2C_REG=0x00
  I2C_WRITE_VALUE=

Examples:
  test_steps.sh 0 0x50
  I2C_WRITE_VALUE=0xbe test_steps.sh 2 0x54
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${I2C_BUS:=0}"
: "${I2C_ADDR:=}"
: "${I2C_REG:=0x00}"
BUS="${1:-$I2C_BUS}"
ADDR="${2:-$I2C_ADDR}"

log()  { echo "[i2c-test] $*"; }
fail() { echo "[i2c-test] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

need i2cdetect
log "Available I2C adapters"
i2cdetect -l

log "Detecting devices on bus $BUS"
i2cdetect -y "$BUS"

if [[ -z "$ADDR" ]]; then
  log "PASS: I2C discovery completed. Set I2C_ADDR for register access."
  exit 0
fi

need i2cget
log "Reading bus=$BUS addr=$ADDR reg=$I2C_REG"
i2cget -y "$BUS" "$ADDR" "$I2C_REG"

if [[ -n "${I2C_WRITE_VALUE:-}" ]]; then
  need i2cset
  log "Writing $I2C_WRITE_VALUE to bus=$BUS addr=$ADDR reg=$I2C_REG"
  i2cset -y "$BUS" "$ADDR" "$I2C_REG" "$I2C_WRITE_VALUE"
  i2cget -y "$BUS" "$ADDR" "$I2C_REG"
fi

log "PASS: I2C read/write smoke completed"
