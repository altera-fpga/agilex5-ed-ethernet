emb-test-suite test-suite package

Platform   : agilex5
Build type : release
Built UTC  : 2026-07-07T01:21:23Z

Quick start - Linux:
  vi config/testsuite.conf     # edit NET_IFACE, PEER_IP, GPIO_PIN, etc.
  ./ts list
  ./ts ping                    # uses PEER_IP from config/testsuite.conf
  ./ts gpio                    # uses GPIO_PIN from config/testsuite.conf
  ./ts iperf-server
  ./ts iperf-client            # uses IPERF_SERVER_IP from config/testsuite.conf
  ./ts menu

Quick start - U-Boot:
  # To include pre-built U-Boot .scr files, rebuild using:
  make PLAT=<plat> BUILD_TYPE=<type> uboot

Notes:
  - Linux defaults are maintained in tools/testsuite/config/<platform>.conf.
  - U-Boot defaults are maintained in tools/testsuite/config/uboot_<platform>.env.
  - The package still includes uboot/mkimage_all.sh for developers who modify
    config/uboot.env or *.cmd after extraction and want to regenerate *.scr.

Package layout:
  test-suite          Main Linux runner
  ts                  Short launcher
  config/             Customer-editable Linux and U-Boot defaults
  tests/              Packaged Linux solution scripts
  uboot/              Packaged U-Boot command scripts and optional .scr images
  assets/             Packaged supporting assets
  logs/               Runtime logs
  manifest.tsv        Packaged Linux test metadata
  uboot_manifest.tsv  Packaged U-Boot script metadata
  metadata.env        Package metadata
