#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run Linux kernel dmatest on discovered DMA channels."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  DMATEST_ITERATIONS=10
  DMATEST_TIMEOUT=2000
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${DMATEST_ITERATIONS:=10}"
: "${DMATEST_TIMEOUT:=2000}"

log()  { echo "[dmatest] $*"; }
fail() { echo "[dmatest] FAIL: $*" >&2; exit 1; }

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then fail "must run as root"; fi
modprobe dmatest 2>/dev/null || true
[[ -d /sys/module/dmatest/parameters ]] || fail "dmatest sysfs parameters not found"

mapfile -t channels < <(ls -1 /sys/class/dma 2>/dev/null || true)
[[ "${#channels[@]}" -gt 0 ]] || fail "no DMA channels found under /sys/class/dma"

printf '%s\n' "$DMATEST_TIMEOUT" > /sys/module/dmatest/parameters/timeout
printf '%s\n' "$DMATEST_ITERATIONS" > /sys/module/dmatest/parameters/iterations
printf '1\n' > /sys/module/dmatest/parameters/verbose 2>/dev/null || true
printf '0\n' > /sys/module/dmatest/parameters/run 2>/dev/null || true

for ch in "${channels[@]}"; do
  log "Adding DMA channel $ch"
  printf '%s\n' "$ch" > /sys/module/dmatest/parameters/channel || true
done

log "Starting dmatest"
printf '1\n' > /sys/module/dmatest/parameters/run
sleep 5

dmesg | grep -i dmatest | tail -80 || true
if dmesg | grep -i dmatest | tail -80 | grep -qi 'fail'; then
  fail "dmatest reported failure in dmesg"
fi
log "PASS: dmatest launched; check dmesg above for detailed channel results"
