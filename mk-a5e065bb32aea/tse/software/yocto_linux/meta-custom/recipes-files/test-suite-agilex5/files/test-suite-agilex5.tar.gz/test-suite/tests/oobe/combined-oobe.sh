#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run OOBE syschk and hello-world applications from the on-board rootfs."

usage() {
  cat <<'USAGE'
Usage:
  test_steps.sh

Environment:
  OOBE_APP_DIR=/home/root/alteraFPGA
  OOBE_SYSCHK_TIMEOUT_SEC=10

This is the on-board test-suite shell version of oobe/linux/combined_oobe/test_steps.pl.
It runs syschk with a bounded timeout, then runs hello and verifies the Hello world banner.
USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${OOBE_APP_DIR:=/home/root/alteraFPGA}"
: "${OOBE_SYSCHK_TIMEOUT_SEC:=10}"

log()  { echo "[combined-oobe] $*"; }
fail() { echo "[combined-oobe] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

need timeout
need grep

[[ -d "$OOBE_APP_DIR" ]] || fail "OOBE app directory not found: $OOBE_APP_DIR"
[[ -x "$OOBE_APP_DIR/syschk" ]] || fail "syschk not executable under $OOBE_APP_DIR"
[[ -x "$OOBE_APP_DIR/hello" ]] || fail "hello not executable under $OOBE_APP_DIR"

cd "$OOBE_APP_DIR"

log "Running syschk for ${OOBE_SYSCHK_TIMEOUT_SEC}s"
set +e
syschk_output="$(timeout "${OOBE_SYSCHK_TIMEOUT_SEC}s" ./syschk 2>&1)"
syschk_rc=$?
set -e
printf '%s\n' "$syschk_output"

# The original Perl test interrupts syschk after observing LED entries. timeout rc=124 is acceptable.
if [[ "$syschk_rc" -ne 0 && "$syschk_rc" -ne 124 ]]; then
  fail "syschk failed with rc=$syschk_rc"
fi

if ! printf '%s\n' "$syschk_output" | grep -Eq 'hps_led|fpga_led'; then
  fail "syschk output did not contain expected LED entries"
fi

log "Running hello"
hello_output="$(./hello 2>&1)"
printf '%s\n' "$hello_output"
printf '%s\n' "$hello_output" | grep -q 'Hello world' || fail "hello output did not contain Hello world"

log "PASS: combined OOBE test completed"
