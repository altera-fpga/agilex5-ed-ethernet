#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Display Linux I3C bus/device enumeration and DesignWare I3C probe logs."

usage() {
  cat <<'EOF'
Usage:
  test_steps.sh

Environment:
  I3C_REQUIRE_DEVICE=0
EOF
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${I3C_REQUIRE_DEVICE:=0}"
log()  { echo "[i3c-probe] $*"; }
fail() { echo "[i3c-probe] FAIL: $*" >&2; exit 1; }

log "I3C sysfs devices"
if [[ -d /sys/bus/i3c/devices ]]; then
  find /sys/bus/i3c/devices -maxdepth 2 -type l -o -type d | sort
else
  [[ "$I3C_REQUIRE_DEVICE" == "1" ]] && fail "/sys/bus/i3c/devices not found"
  log "No I3C sysfs bus found; kernel may not enable I3C on this image"
fi

log "Recent I3C-related kernel logs"
dmesg | grep -iE 'i3c|dw.*i3c|designware' | tail -50 || true
log "PASS: I3C probe inspection completed"
