#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (C) 2026 Altera Corporation
# SPDX-License-Identifier: MIT-0
set -euo pipefail

DESCRIPTION="Run multicast MAC smoke test using the on-board Ethernet interface."

usage() {
  cat <<'USAGE'
Usage:
  test_steps.sh [iface]

Environment:
  NET_IFACE=eth0
  MCAST_GROUP=224.0.50.50
  MCAST_DST_MAC=01:00:5e:01:01:01
  MCAST_PACKET_COUNT=5

This is the on-board test-suite shell version of networking/linux/ETH/Config1/mac_addr_multicast_test/test_steps.pl.
It adds a multicast route, sends multicast packets from the board using scapy when available,
and prints NIC statistics before/after for manual comparison.
USAGE
}

if [[ "${1:-}" == "--desc" ]]; then echo "$DESCRIPTION"; exit 0; fi
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

: "${NET_IFACE:=eth0}"
: "${MCAST_GROUP:=224.0.50.50}"
: "${MCAST_DST_MAC:=01:00:5e:01:01:01}"
: "${MCAST_PACKET_COUNT:=5}"

IFACE="${1:-$NET_IFACE}"

log()  { echo "[mac-multicast] $*"; }
fail() { echo "[mac-multicast] FAIL: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  fail "this test requires root privileges to modify multicast routes"
fi

need ip
need python3

ip link show "$IFACE" >/dev/null || fail "interface not found: $IFACE"

cleanup() {
  ip route del 224.0.0.0/4 dev "$IFACE" >/dev/null 2>&1 || true
}
trap cleanup EXIT

log "Interface: $IFACE"
ip -d link show "$IFACE"

log "Adding multicast route"
ip route replace 224.0.0.0/4 dev "$IFACE"

log "Statistics before"
ethtool -S "$IFACE" 2>/dev/null | grep -i 'multicast\|mcast\|rx_\|tx_' | head -40 || true

log "Sending ${MCAST_PACKET_COUNT} multicast packets to ${MCAST_GROUP}/${MCAST_DST_MAC}"
python3 - "$IFACE" "$MCAST_DST_MAC" "$MCAST_GROUP" "$MCAST_PACKET_COUNT" <<'PY'
import sys
iface, dst_mac, group, count = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
try:
    from scapy.all import Ether, IP, sendp
except Exception as exc:
    raise SystemExit(f"scapy is required for packet generation: {exc}")
sendp(Ether(dst=dst_mac)/IP(dst=group, ttl=1), count=count, iface=iface, verbose=False)
PY

sleep 2

log "Statistics after"
ethtool -S "$IFACE" 2>/dev/null | grep -i 'multicast\|mcast\|rx_\|tx_' | head -40 || true

log "PASS: multicast packet generation completed"
