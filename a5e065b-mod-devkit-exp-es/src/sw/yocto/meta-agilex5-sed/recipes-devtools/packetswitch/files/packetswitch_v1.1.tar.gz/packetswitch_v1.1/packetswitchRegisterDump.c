/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Switch Application v2.0                              **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include <stdio.h>
#include "packetswitchRegisterMap.h"
#include "packetswitchRegisterInterface.h"
/**
 * @brief Copies a block of memory from one location to another in 32bit chunks.
 *
 * This function copies `n` bytes of memory from the source address `src` to the destination address `dest`.
 * The memory areas must not overlap.
 *
 * @param dest Pointer to the destination memory address.
 * @param src Pointer to the source memory address.
 * @param n Number of bytes to copy.
 *
 * @return Pointer to the destination memory address.
 */
void *memcpy32(uint32_t *dest, const uint32_t *src, size_t count) {
	if (dest == NULL || src == NULL) {
		return NULL;
	}
	// Copy 'count' 32-bit chunks from 'src' to 'dest'
	for (size_t i = 0; i < count; ++i) {
		//printf("Dest: %p Src: %p value: 0X%X\n", &dest[i], &src[i], src[i]);
		fflush(stdout);
		dest[i] = src[i];
		sleep(0);
	}

	return dest;
}
/**
 * @brief Function to dump the general status structure
 * 
 * This function prints the current general status register of the PacketSwitch.
 * It provides general information about the PacketSwitch IP.
 * 
 * @param ingressArbiter Pointer to the ingress arbiter structure from the Packet Switch
 * @return void
 */
void dumpGeneralStatus (packetSwitchGeneral_t *pGeneral)
{
	packetSwitchGeneral_t general;
	memcpy32((uint32*)(&general), (uint32*)(pGeneral), sizeof(packetSwitchGeneral_t)/4);
	printf("General Status - \n");
	printf("\tScratch Register: 0x%X \n", general.generalReg.scratchReg);
	printf("\tGeneral Status: \n");
	printf("\t\tVersion: %d.%d\n", general.generalReg.statusReg.status.majorVersion, general.generalReg.statusReg.status.minorVersion);
	printf("\t\tInit status - Tx Init: %s. Rx Init: %s\n", 
			((general.generalReg.statusReg.status.txInitDone == 1)? "Done": "Pending"),
			((general.generalReg.statusReg.status.rxInitDone == 1)? "Done": "Pending"));
	printf("\t\tHSSI Ports: %d DMA ports: %d User Ports: %d\n", general.generalReg.statusReg.status.hssiUserPorts, 
			general.generalReg.statusReg.status.dmaPorts, general.generalReg.statusReg.status.userPorts);
	printf("\t\tDebug Counters support: %s\n", ((general.generalReg.statusReg.status.dbgCntrEnable == 1)? "Supported": "Not Supported"));
	
	return;
}
/**
 * @brief Function to dump the ingress arbiter structure
 * 
 * This function prints the current state of the ingress arbiter.
 * It provides information about the arbiter's configuration and status.
 * 
 * @param ingressArbiter Pointer to the ingress arbiter structure from the Packet Switch
 * @return void
 */
void dumpIngressArbiter (ingressArbiter_t *pIngressArbiter, int dmaPorts, int userPorts)
{
	ingressArbiter_t ingressArbiter;
	memcpy32((uint32*)(&ingressArbiter), (uint32*)(pIngressArbiter), sizeof(ingressArbiter_t)/4);
	printf("\t\tIngress Arbiter - \n");
	printf("\t\t\tScratch Register: 0x%X \n", ingressArbiter.scratchReg);
	printf("\t\t\tDMA Priorities - \n");
	for (int i=0; i < dmaPorts; i++) {
		printf("\t\t\t\tDMA Port -%d - %d\n", i, ingressArbiter.cfgPriorityDma.priority[i/2].ch0);
		i++;
		if (i<dmaPorts) {
			printf("\t\t\t\tDMA Port -%d - %d\n", i, ingressArbiter.cfgPriorityDma.priority[i/2].ch1);
		}
	} 
	printf("\t\t\tUser Port Priorities - \n");
	for (int i=0; i < userPorts; i++) {
		printf("\t\t\t\tUser Port -%d - %d\n", i, ingressArbiter.cfgPriorityUser.priority[i/2].ch0);
		i++;
		if (i<userPorts) {
			printf("\t\t\t\tUser Port -%d - %d\n", i, ingressArbiter.cfgPriorityUser.priority[i/2].ch1);
		}
	} 
	return;
}
/**
 * @brief Function to dump the ingress arbiter structure for multiple ports
 *
 * This function retrieves and prints the values of the ingress arbiter multiple.
 * 
 * @param ingressArbiter Pointer to the ingress arbiter structure array from the Packet Switch
 * @param port Port number to dump the ingress arbiter structure
 * @return void
 */
void dumpIngressArbiterMultiple (packetSwitch_t *packetSwitch, int port)
{
	int i = 0;
	ingressArbiter_t *ingressArbiter = NULL;
	int max = getNumHSSIPorts(&(packetSwitch->generalStatus));
	if (port < max) {
		i = port; max = i+1;	
	}
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		ingressArbiter = &(packetSwitch->port[i].ingressArbiter);
		dumpIngressArbiter(ingressArbiter, getNumDMAPorts(&(packetSwitch->generalStatus)), getNumUserPorts(&(packetSwitch->generalStatus)));
	}
}
/**
 * @brief Function to dump the egress RX demux structure
 * 
 * This function prints the current state of the egress RX demux structure.
 * 
 * @param egressRXDemux Pointer to the egress RX demux structure from the Packet Switch
 * @return void
 */
void dumpEgressRXDemux (egressRXDemux_t *pEgressRXDemux, int dmaPorts)
{
	egressRXDemux_t egressRXDemux;
	memcpy32((uint32*)(&egressRXDemux), (uint32*)(pEgressRXDemux), sizeof(egressRXDemux_t)/4);
	printf("\t\tEgress RX Demux - \n");
	printf("\t\t\tScratch Register: 0x%X \n", egressRXDemux.scratchReg);
	printf("\t\t\tDMA Drop Configuration - 0x%x\n", egressRXDemux.controlReg);
	for (int i=0; i < dmaPorts; i++) {
		printf("\t\t\t\tDMA-%d - %s\n", i, ((egressRXDemux.controlReg & (1<<dmaPorts))?"Enabled":"Disabled"));
	} 
	printf("\t\t\tDMA Drop threshold -\n");
	for (int i=0; i < dmaPorts; i++) {
		printf("\t\t\t\tDMA-%d - %d\n", i, egressRXDemux.dmaDropThresholdReg[i]);
	} 
	return;
}

/**
 * @brief Dump the egress RX demux for multiple ports.
 *
 * This function retrieves and prints the values of the egress arbiter structure from the array.
 * 
 * @param egressRXDemux Pointer to the egress arbiter structure array from the Packet Switch
 * @param port Port number to dump the ingress arbiter structure
 * @return void
 *
 * @return None.
 */
void dumpEgressRXDemuxMultiple(packetSwitch_t *packetswitch, int port)
{
	int i = 0;
	egressRXDemux_t *egressRXDemux;
	int max = getNumHSSIPorts(&(packetswitch->generalStatus));
	if (port < max) {
		i = port; max = i+1;	
	}
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		egressRXDemux = &(packetswitch->port[i].egressRXDemux);
		dumpEgressRXDemux(egressRXDemux, getNumDMAPorts(&(packetswitch->generalStatus)));
	}
	return;
}
/**
 * @brief Function to dump the ingress RX Width adapter structure
 * 
 * This function prints the current state of the ingress RX Width adapter structure.
 * 
 * @param ingressRXWidthAdapter Pointer to the ingress RX Width adapter structure from the Packet Switch
 * @return void
 */
void dumpIngressRXWidthAdapter(ingressRXWidthAdapter_t *pIingressRXWidthAdapter)
{
	ingressRXWidthAdapter_t ingressRXWidthAdapter;
	memcpy32((uint32*)(&ingressRXWidthAdapter), (uint32*)(pIingressRXWidthAdapter), sizeof(ingressRXWidthAdapter_t)/4);
	printf("\t\tIngress RX Width Adapter - \n");
	printf("\t\t\tScratch Register: 0x%X \n", ingressRXWidthAdapter.scratchReg);
	printf("\t\t\tRx Pause - %s\n", ((ingressRXWidthAdapter.controlReg.control.rxPauseEnable)?"Enabled":"Disabled"));
	printf("\t\t\tRx Pause Threshold: %d Rx Drop threshold: %d\n", ingressRXWidthAdapter.thresholdReg.threshold.rxPauseThreshold,
		    ingressRXWidthAdapter.thresholdReg.threshold.dropThreshold);
	return;
}

/**
 * @brief Dump the ingress RX Width adapter for multiple ports.
 *
 * This function retrieves and prints the values of the ingress RX Width adapter structure from the array.
 * 
 * @param ingressRXWidthAdapter Pointer to the ingress RX Width adapter structure array from the Packet Switch
 * @param port Port number to dump the ingress arbiter structure
 * @return void
 *
 * @return None.
 */
void dumpIngressRXWidthAdapterMultiple (packetSwitch_t *packetswitch, int port)
{
	int i = 0;
	ingressRXWidthAdapter_t *ingressRXWidthAdapter;
	int max = getNumHSSIPorts(&(packetswitch->generalStatus));
	if (port < max) {
		i = port; max = i+1;	
	}
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		ingressRXWidthAdapter = &(packetswitch->port[i].ingressRXWidthAdapter);
		dumpIngressRXWidthAdapter(ingressRXWidthAdapter);
	}
}
/**
 * @brief Function to dump the egress RX Width adapter structure
 * 
 * This function prints the current state of the egress RX Width adapter structure.
 * 
 * @param egressRXWidthAdapter Pointer to the egress RX Width adapter structure from the Packet Switch
 * @return void
 */
void dumpEgressRXWidthAdapter(egressRXWidthAdapter_t *pEgressRXWidthAdapter)
{
	egressRXWidthAdapter_t egressRXWidthAdapter;
	memcpy32((uint32*)(&egressRXWidthAdapter), (uint32*)(pEgressRXWidthAdapter), sizeof(egressRXWidthAdapter_t)/4);
	printf("\t\tEgress RX Width Adapter - \n");
	printf("\t\t\tScratch Register: 0x%X \n", egressRXWidthAdapter.scratchReg);
	printf("\t\t\tDrop enabled - %s\n", ((egressRXWidthAdapter.controlReg.control.dropEnable)?"Enabled":"Disabled"));
	printf("\t\t\tDrop Threshold: %d\n", egressRXWidthAdapter.dropThresholdReg.threshold.dropThreshold);
	
	return;
}
/**
 * @brief Dump the egress RX Width adapter for multiple ports.
 *
 * This function retrieves and prints the values of the egress RX Width adapter structure from the array.
 * 
 * @param egressRXWidthAdapter Pointer to the egress RX Width adapter structure array from the Packet Switch
 * @param port Port number to dump the egress arbiter structure
 * @return void
 *
 * @return None.
 */
void dumpEgressRXWidthAdapterMultiple(packetSwitch_t *packetswitch, int port)
{
	int i = 0;
	egressRXWidthAdapter_t *egressRXWidthAdapter;
	int max = getNumHSSIPorts(&(packetswitch->generalStatus));
	if (port < max) {
		i = port; max = i+1;	
	}
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		egressRXWidthAdapter = &(packetswitch->port[i].egressRXWidthAdapter);
		dumpEgressRXWidthAdapter(egressRXWidthAdapter);
	}
	return;
}
/**
 * @brief Dumps the TCAM register feature list look-up type.
 *
 * This function is responsible for dumping the T-CAM register feature list look-up type.
 * It provides information about the type of look-up used in the CAM register feature list.
 *
 * @param None
 * @return None
 */
const char* dumptcamRegisterFeatureListLookUpType(featureList_t *featureList)
{
	featureList_t feat;
	feat.value = *(uint32*)(featureList);
	uint8 lookUpType = FEATURE_LIST_LOOK_UP_TYPE_GET(feat.feature.look_up_type);
	if (IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_EM_MBL(lookUpType)) return "PPBB-EM-MBL";
	if (IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_MS_TCAM(lookUpType)) return "PPBB-MS_TCAM";
	if (IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_MC_BCAM(lookUpType)) return "PPBB-MC_BCAM";
	return "Not known";
}
/**
 * @brief Dumps the register feature list.
 *
 * This function is used to dump the register feature list.
 * It provides a detailed view of the register features.
 * 
 * @param featureList Pointer to the feature list register
 * 
 * @return None
 */
void dumptcamRegisterFeatureList(featureList_t *featureList)
{
	featureList_t feat;
	feat.value = *(uint32*)(featureList);
	printf("\t\tFeature List - 0x%X AXI4 Support: %s Look up Type: %s [0x%X]\n", 
			feat.value,
			(feat.feature.interface_support == FEATURE_LIST_AXI4_INTERFACE_SUPPORT ? "Yes":"NO"),
			dumptcamRegisterFeatureListLookUpType(featureList),
			FEATURE_LIST_LOOK_UP_TYPE_GET(feat.feature.look_up_type));
}
/**
 * @brief Dumps the register interface attributes.
 *
 * This function is responsible for dumping the attributes of the register interface.
 * It provides information about the register interface's attributes.
 *
 * @param attribute Pointer to the attibute register
 * @return None
 */
void dumptcamRegisterInterfaceAttributes(interfaceAttributes_t *attribute)
{
	interfaceAttributes_t attr;
	attr.value = *(uint32*)(attribute);
	printf("\t\tInterface Atributes: 0x%X AXI ST ready Latency: %d AXI Lite Data Width: %s\n",
			attr.value, INTERFACE_ATTRIBUTES_AXI_ST_READY_LATENCY_MASK_GET(attr.attribute.ready_latency),
			((attr.attribute.axilite_data_width == INTERFACE_ATTRIBUTES_AXILITE_DATA_WIDTH_32BIT)?"32 bit":"64 bit"));
	return;
}
/**
 * @brief Dumps the TCAM register for general control.
 *
 * This function is used to dump the TCAM register for general control.
 * It provides information about the current state of the TCAM register
 * and can be used for debugging and troubleshooting purposes.
 *
 * @param general_control Pointer to the general control register
 * @return None
 */
void dumptcamRegisterGeneralControl(generalControl_t *general_control)
{
	generalControl_t ctrl;
	ctrl.value = *(uint32*)(general_control);
	printf("\t\tGeneral Control: 0x%X Init Done: %s\n", ctrl.value,
			((GENERAL_CONTROL_INIT_DONE_GET(ctrl.gen_ctrl.init_done)==GENERAL_CONTROL_INIT_DONE_NOT_DONE)?"No":"Yes"));
	return;
}
/**
 * @brief Dumps the TCAM register management control operation type.
 *
 * This function is used to dump the control operation type of the TCAM management register.
 * It provides information about the type of operation being performed on the TCAM register.
 *
 * @param opType The control operation type of the TCAM register management.
 * 
 * @return The string representation of the operation type.
 */
const char* dumptcamRegisterMgmtControlOpType(mgmtControl_t *mgmt_control)
{
	mgmtControl_t mgmt;
	mgmt.value = *(uint32*)(mgmt_control);
	switch (MGMT_CONTROL_OP_TYPE_GET(mgmt.mgmt_ctrl.op_type)) {
		case MGMT_CONTROL_OP_TYPE_FLUSH: return "Flush";
		case MGMT_CONTROL_OP_TYPE_INSERT_ENTRY: return "Insert";
		case MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_ENTRYID: return "Delete Using Entry ID";
		case MGMT_CONTROL_OP_TYPE_SEARCH_ENTRY: return "Search Entry";
		case MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_KEY: return "Delete Using Key";
		default: break;
	}
	return "Unknown";
}
/**
 * @brief Dumps the TCAM register management control register values.
 *
 * This function is dumps the TCAM management register value content in a human
 * readable format
 * 
 * @param mgmt_control Pointer to the management control register
 *
 * @return void
 */
void dumptcamRegisterMgmtControl(mgmtControl_t *mgmt_control)
{
	mgmtControl_t mgmt;
	mgmt.value = *(uint32*)(mgmt_control);
	printf("\t\tManagement Control: 0x%X Op Type: %s[0x%d] Success: %s Busy: %s\n", mgmt.value,
			dumptcamRegisterMgmtControlOpType(mgmt_control), MGMT_CONTROL_OP_TYPE_GET(mgmt.mgmt_ctrl.op_type),
			((MGMT_CONTROL_SUCCESS_GET(mgmt.mgmt_ctrl.success)==MGMT_CONTROL_SUCCESS_POSITIVE)?"Yes":"No"),
			((MGMT_CONTROL_BUSY_GET(mgmt.mgmt_ctrl.busy)==MGMT_CONTROL_BUSY_POSITIVE)?"Yes":"No"));
	return;
}
/**
 * @brief Dumps the TCAM warning register.
 *
 * This function is responsible for dumping the TCAM warning register.
 * 
 * @param warning The warning register value
 * 
 * @return None
 */
void dumptcamRegisterWarning(uint32 warning)
{
	printf("\t\tWarning: 0x%X %s%s%s\n", warning,
			((warning & WARNING_UNSUPPORTED_CPU_SPACE)? "Unsupported CPU Space ":""),
			((warning & WARNING_ENTRY_OUT_OF_RANGE)? "Entry out of range ":""),
			((warning & WARNING_UNSUPPORTED_OP_TYPE)? "Unsupported Op type ":""));
}
/**
 * Function to dump the TCAM register fatal error.
 *
 * This function is responsible for dumping the TCAM register fatal error.
 * It provides information about the error that occurred in the TCAM register.
 * 
 * @param fatal_error The fatal error register value
 * 
 * @return void
 */
void dumptcamRegisterFatalError(uint32 fatal_error)
{
	printf("\t\tFatal Error: 0x%X %s%s\n", fatal_error,
			((fatal_error & FATAL_ERROR_MGMT_INTF_INVALID_OPCODE)?"Management interface invalid opcode ":""),
			((fatal_error & FATAL_ERROR_REQUEST_FIFO_FULL)?"Request Fifo Full ":""));
}
/**
 * @brief Prints the MAC address.
 *
 * This function prints the MAC address passed to it.
 * 
 * @param macAddr Pointer to the MAC address structure
 * @param header The header to print before the MAC address
 * 
 * @result none
 */
void print_mac_address(const mac_address *macAddr, const char *header) {
	printf("%s %02X:%02X:%02X:%02X:%02X:%02X", header,
			macAddr->mac.byte_0,
			macAddr->mac.byte_1,
			macAddr->mac.byte_2,
			macAddr->mac.byte_3,
			macAddr->mac.byte_4,
			macAddr->mac.byte_5);
	return;
}
/**
 * @brief Get the Packet Switch Key Flag Field
 *
 * @param pkey Pointer to the key structure
 * @return the flag Field value
 */
uint16 gettcamRegisterPacketSwitchKeyFlagField(packetSwitchKey_t *pkey)
{
	uint16 flagField = 0;
	flagField |= (pkey->key.flagField_low & PACKET_SWITCH_KEY_FLAG_FIELD_LOW_MASK);
	flagField |= ((pkey->key.flagField_high & PACKET_SWITCH_KEY_FLAG_FIELD_HIGH_MASK) << 0x4);
	return flagField;
}
/**
 * @brief Dumps the Key.
 *
 * Dumps a particular Key
 * 
 * @param
 *
 * @return void
 */
void dumptcamRegisterPacketSwitchKey(packetSwitchKey_t *pkey)
{
	char str[INET6_ADDRSTRLEN];
	print_mac_address(&pkey->key.dst_mac, "\t\t\tDestination Mac Address   	:"); printf("\n");
	print_mac_address(&pkey->key.src_mac, "\t\t\tSource Mac Address  		:"); printf("\n");

	memset (str, 0, INET6_ADDRSTRLEN);
	if (memcmp(((uint8*)(((uint8*)(&(pkey->key.dst_ip))) + SIZE_OF_IPV4_ADDRESS)), ((uint8*)(str)),12) == 0) {
		littleEndianToBigEndian_32((uint32*)(&(pkey->key.dst_ip.ipv4)));
		if (inet_ntop(AF_INET, &(pkey->key.dst_ip.ipv4), str, INET_ADDRSTRLEN) != NULL) {
			printf("\t\t\tDestination IP Address		: %s\n", str);
		}
	} else {
		littleEndianToBigEndian_in6Addr(&(pkey->key.dst_ip.ipv6));
		if (inet_ntop(AF_INET6, &(pkey->key.dst_ip.ipv6), str, INET_ADDRSTRLEN) != NULL) {
			printf("\t\t\tDestination IP Address      	: %s\n", str);
		}		
	}
	memset (str, 0, INET6_ADDRSTRLEN);
	if (memcmp((((uint8*)(&(pkey->key.src_ip))) + SIZE_OF_IPV4_ADDRESS), ((uint8*)(str)),12) == 0) {
		littleEndianToBigEndian_32((uint32*)(&(pkey->key.src_ip.ipv4)));
		if (inet_ntop(AF_INET, &(pkey->key.src_ip.ipv4), str, INET_ADDRSTRLEN) != NULL) {
			printf("\t\t\tSource IP Address		: %s\n", str);
		}
	} else {
		littleEndianToBigEndian_in6Addr(&(pkey->key.src_ip.ipv6));
		if (inet_ntop(AF_INET6, &(pkey->key.src_ip.ipv6), str, INET_ADDRSTRLEN) != NULL) {
			printf("\t\t\tSource IP Address		: %s\n", str);
		}		
	}
	printf("\t\t\tDestination Port		: %d\n", pkey->key.l4_dst_port);
	printf("\t\t\tSource Port			: %d\n", pkey->key.l4_src_port);
	printf("\t\t\tTCI VLANB			: %d\n", pkey->key.tci_vlanb);
	printf("\t\t\tTCI VLANA			: %d\n", pkey->key.tci_vlana);
	printf("\t\t\tEthernet Type			: 0x%X\n", PACKET_SWITCH_KEY_ETHTYPE_GET(pkey->key.ethtype));
	printf("\t\t\tIP Protocol			: 0x%X\n", PACKET_SWITCH_KEY_IP_PROTOCOL_GET(pkey->key.ip_protocol));
	printf("\t\t\tMessage Type			: 0x%X\n", PACKET_SWITCH_KEY_MESSAGE_TYPE_GET(pkey->key.messageType));
	printf("\t\t\tFlag Field			: 0x%X\n", gettcamRegisterPacketSwitchKeyFlagField(pkey));
}

/**
 * @brief Dumps the key after copying the Key from the TCAM space.
 *
 * Function to dump the key after copying the Key from the TCAM space
 *
 * @param keys Pointer to the packetSwitchKey_t structure
 */
void dumptcamRegisterPacketSwitchKeyMultiple(packetSwitchKey_t *keys)
{
	packetSwitchKey_t temp;
	printf("\t\tKey\n");
	memcpy32((uint32*)&temp, (uint32*)keys, (sizeof(packetSwitchKey_t)/4));
	dumptcamRegisterPacketSwitchKey(&temp);
	return;
}
/**
 * @brief Dumps the contents of the TCAM register Packet Switch array.
 *
 * This function is used to retrieve and print the contents of the TCAM register Packet Switch array.
 *
 * @return None.
 */
void dumptcamRegisterPacketSwitchArray(uint32 *array, int num, const char *header)
{
	int i = 0;
	printf("\t\t%s\n\t\t\t", header);
	for (i=0;i<num;i++) {
		printf("0x%X ", *(array+i));
		if (i%4 == 3) printf("\n\t\t\t");
	}
	printf("\n");
}

/**
 * @brief Dumps the contents of the TCAM register set.
 *
 * This function prints out the contents of the TCAM register set.
 * It provides a detailed view of the register values for debugging purposes.
 *
 * @param tcamRegisterSet Pointer to the TCAM register set
 * @return None
 */
void dumptcamRegisterSet(tcamRegisterSet_t *tcamRegisterSet)
{
	printf("\t\tVersion: %d \n", (tcamRegisterSet->version & TCAM_VERSION_MASK));
	dumptcamRegisterFeatureList(&tcamRegisterSet->feature_list);
	sleep(0);
	dumptcamRegisterInterfaceAttributes(&tcamRegisterSet->attr);
	sleep(0);
	printf("\t\tScratch register: 0x%X\n", tcamRegisterSet->scratch_reg);
	dumptcamRegisterGeneralControl(&tcamRegisterSet->general_control);
	sleep(0);
	dumptcamRegisterMgmtControl(&tcamRegisterSet->mgmt_control);
	sleep(0);
	printf("\t\tEntry: 0x%X\n",tcamRegisterSet->entry);
	dumptcamRegisterWarning(tcamRegisterSet->warning);
	sleep(0);
	dumptcamRegisterFatalError(tcamRegisterSet->fatal_error);
	sleep(0);
	printf("\t\tMonitor: 0x%X\n",tcamRegisterSet->monitor);
	dumptcamRegisterPacketSwitchKeyMultiple(&(tcamRegisterSet->key));
	sleep(0);
	printf("\t\tResult: 0x%X\n",tcamRegisterSet->result[0]);
	dumptcamRegisterPacketSwitchArray(tcamRegisterSet->match, MAX_TCAM_MATCH_REG, "Match");
	sleep(0);
	dumptcamRegisterPacketSwitchArray(tcamRegisterSet->mask.masks, sizeof(packetSwitchMask_t)/4, "Mask");
	sleep(0);
}
/**
 * @brief Dumps the contents of the TCAM register set for multiple ports.
 *
 * This function retrieves and prints the values of the TCAM register set from the array.
 * 
 * @param tcamRegisterSet Pointer to the TCAM register set array from the Packet Switch
 * @param port Port number to dump the TCAM register set
 * @return void
 */
void dumptcamRegisterSetMultiple(packetSwitch_t *packetswitch, int port)
{
	int i = 0;
	tcamRegisterSet_t *tcamRegisterSet;
	int max = getNumHSSIPorts(&(packetswitch->generalStatus));
	if (port < max) {
		i = port; max = i+1;	
	}
	for (; i < max; i++) {
		printf("\tPort %d - TCAM Registers\n", i);
		tcamRegisterSet = &(packetswitch->port[i].tcam);
		dumptcamRegisterSet(tcamRegisterSet);
	}
	return;
}

#ifdef DEBUG_REG_SUPPORT
/**
 * @brief Dumps the contents of the TX debug registers of the PacketSwitch for multiple ports.
 *
 * This function retrieves and prints the values of the TX debug registers of the PacketSwitch.
 * 
 * @param base Pointer to the register set array
 * @param port Port number to dump the TCAM register set
 * @return void
 */
void dumpTxDebugRegistersMultiple (packetSwitchTxDebugReg_t *base, int port)
{
	int i = 0;
	packetSwitchTxDebugReg_t *txDebug = NULL;
	int max = MAX_NUM_PORTS_SUPPORTED;
	if (port < MAX_NUM_PORTS_SUPPORTED) {
		i = port; max = i+1;
	}
	printf("Tx Debug Registers -\n");
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		txDebug = &base[i];
		printf("\t\tdma2iwadj_ch0_stats_reg: 0x%X\n", txDebug->txDebugReg.dma2iwadj_ch0_stats_reg);
		printf("\t\tdma2iwadj_ch1_stats_reg: 0x%X\n", txDebug->txDebugReg.dma2iwadj_ch1_stats_reg);
		printf("\t\tdma2iwadj_ch2_stats_reg: 0x%X\n", txDebug->txDebugReg.dma2iwadj_ch2_stats_reg);
		printf("\t\tiwadj2iarb_ch0_stats_reg: 0x%X\n", txDebug->txDebugReg.iwadj2iarb_ch0_stats_reg);
		printf("\t\tiwadj2iarb_ch1_stats_reg: 0x%X\n", txDebug->txDebugReg.iwadj2iarb_ch1_stats_reg);
		printf("\t\tiwadj2iarb_ch2_stats_reg: 0x%X\n", txDebug->txDebugReg.iwadj2iarb_ch2_stats_reg);
		printf("\t\tuser2iarb_stats_reg: 0x%X\n", txDebug->txDebugReg.user2iarb_stats_reg);
		printf("\t\tiarb2hssi_stats_reg: 0x%X\n", txDebug->txDebugReg.iarb2hssi_stats_reg);
	}
}

/**
 * @brief Dumps the contents of the RX debug registers of the PacketSwitch for multiple ports.
 *
 * This function retrieves and prints the values of the RX debug registers of the PacketSwitch.
 * 
 * @param base Pointer to the register set array
 * @param port Port number to dump the TCAM register set
 * @return void
 */
void dumpRxDebugRegistersMultiple (packetSwitchRxDebugReg_t *base, int port)
{
	int i = 0;
	packetSwitchRxDebugReg_t *rxDebug = NULL;
	int max = MAX_NUM_PORTS_SUPPORTED;
	if (port < MAX_NUM_PORTS_SUPPORTED) {
		i = port; max = i+1;
	}
	printf("Rx Debug Registers -\n");
	for (; i < max; i++) {
		printf("\tPort %d\n", i);
		rxDebug = &base[i];
		printf("\t\thssi2iwadj_stats_reg: 0x%X\n", rxDebug->rxDebugReg.hssi2iwadj_stats_reg);
		printf("\t\tiwadj2pars_stats_reg: 0x%X\n", rxDebug->rxDebugReg.iwadj2pars_stats_reg);
		printf("\t\tpars2lkup_stats_reg: 0x%X\n", rxDebug->rxDebugReg.pars2lkup_stats_reg);
		printf("\t\tlkup_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.lkup_drop_stats_reg);
		printf("\t\tlkup2ewadj_user_stats_reg: 0x%X\n", rxDebug->rxDebugReg.lkup2ewadj_user_stats_reg);
		printf("\t\tewadj2user_stats_reg: 0x%X\n", rxDebug->rxDebugReg.ewadj2user_stats_reg);
		printf("\t\tewadj_user_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.ewadj_user_drop_stats_reg);
		printf("\t\tlkup2ewadj_dma_stats_reg: 0x%X\n", rxDebug->rxDebugReg.lkup2ewadj_dma_stats_reg);
		printf("\t\tewadj2dmux_dma_stats_reg: 0x%X\n", rxDebug->rxDebugReg.ewadj2dmux_dma_stats_reg);
		printf("\t\tdmux_dma_0_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux_dma_0_drop_stats_reg);
		printf("\t\tdmux_dma_1_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux_dma_1_drop_stats_reg);
		printf("\t\tdmux_dma_2_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux_dma_2_drop_stats_reg);
		printf("\t\tdmux2dma_0_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux2dma_0_stats_reg);
		printf("\t\tdmux2dma_1_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux2dma_1_stats_reg);
		printf("\t\tdmux2dma_2_stats_reg: 0x%X\n", rxDebug->rxDebugReg.dmux2dma_2_stats_reg);
		printf("\t\trx_iwadj_drop_stats_reg: 0x%X\n", rxDebug->rxDebugReg.rx_iwadj_drop_stats_reg);
	}
}
#endif
/**
 * @brief Dumps the details of the Packet Switch.
 *
 * This function is responsible for dumping the details of the Packet Switch.
 * It provides information about the bridge's configuration, status, and
 * connected devices.
 *
 * @param packetSwitch Pointer to the Packet Switch structure
 * @param port Port number to dump the Packet Switch details
 * @return None
 */
void dumpPacketSwitchDetails(packetSwitch_t *packetSwitch, int port)
{
	dumpGeneralStatus(&(packetSwitch->generalStatus));
	sleep(0);
	dumpIngressArbiterMultiple(packetSwitch, port);
	sleep(0);
	dumpEgressRXDemuxMultiple(packetSwitch, port);
	sleep(0);
	dumpIngressRXWidthAdapterMultiple(packetSwitch, port);
	sleep(0);
	dumpEgressRXWidthAdapterMultiple(packetSwitch, port);
	sleep(0);
#ifdef DEBUG_REG_SUPPORT
	dumpTxDebugRegistersMultiple(packetSwitch->txDebug,port);
	dumpRxDebugRegistersMultiple(packetSwitch->rxDebug,port);
#endif
	return;
}
