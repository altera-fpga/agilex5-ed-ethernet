/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Switch Application v2.0                              **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#ifndef __PACKET_SWITCH_REGISTER_INTERFACE_H__
#define __PACKET_SWITCH_REGISTER_INTERFACE_H__

#include "packetswitchRegisterMap.h"
#include <stdbool.h>

#define SIZEOF_MAC_ADDRESS 20
void setIngressArbiterScratchReg(ingressArbiter_t *ingressArbiter, uint32 reg);
void setIngressArbiterDMAConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri);
void setIngressArbiterUserConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri);

void setEgressRXDemuxScratchReg(egressRXDemux_t *egressRXDemux, uint32 reg);
void setEgressRXDemuxDropConfig(egressRXDemux_t *egressRXDemux, uint32 port, bool enable);
void setEgressRXDemuxDMADropThresholdReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);

void setIngressRXWidthAdapterScratchReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 reg);
void setIngressRXWidthAdapterRxPauseEnable(ingressRXWidthAdapter_t *ingressRXWidthAdapter, bool enable);
void setIngressRXWidthAdapterCfgRxPauseThresholdReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 threshold);
void setIngressRXWidthAdapterCfgDropThresholdReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 threshold);

void setEgressRXWidthAdapterScratchReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 reg);
void setEgressRXWidthAdapterControlDrop(egressRXWidthAdapter_t *egressRXWidthAdapter, bool enable);
void setEgressRXWidthAdapterCfgDropThresholdReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 threshold);

void settcamRegisterScratchReg(tcamRegisterSet_t *tcamRegisterSet, uint32 reg);

int checktcamGeneralControlInitDone(tcamRegisterSet_t *tcamRegisterSet);
void tcamMgmtControlWaitTillBusyDone(tcamRegisterSet_t *tcamRegisterSet);
int tcamMgmtControlOperationResult(tcamRegisterSet_t *tcamRegisterSet);

int tcamMgmtControlSetOpType(tcamRegisterSet_t *tcamRegisterSet, uint32 opType);
int tcamSetEntry(tcamRegisterSet_t *tcamRegisterSet, uint32 entry);
int tcamWarningReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *warning);
int tcamWarningReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *warning);
int tcamMonitorReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *monitor);
int settcamRegisterPacketSwitchKeyDestMacAddress(packetSwitchKey_t *key, packetSwitchMask_t *mask, char *mac);
int settcamRegisterPacketSwitchKeySrcMacAddress(packetSwitchKey_t *key, packetSwitchMask_t *mask, char *mac);
int settcamRegisterPacketSwitchKeyDestIPAddress(packetSwitchKey_t *key, packetSwitchMask_t *mask, char *ipaddr);
int settcamRegisterPacketSwitchKeySrcIPAddress(packetSwitchKey_t *key, packetSwitchMask_t *mask, char *ipaddr);
int settcamRegisterPacketSwitchKeyDestL4Port(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 port);
int settcamRegisterPacketSwitchKeySrcL4Port(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 port);
int settcamRegisterPacketSwitchKeyVLANB(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 vlan);
int settcamRegisterPacketSwitchKeyVLANA(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 vlan);
int settcamRegisterPacketSwitchKeyEthType(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 ethType);
int settcamRegisterPacketSwitchKeyIPProtocol(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint8 ipProtocol);
int settcamRegisterPacketSwitchKeyMessageType(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint8 type);
int settcamRegisterPacketSwitchKeyFlagField(packetSwitchKey_t *key, packetSwitchMask_t *mask, uint16 flag);

int settcamRegisterPacketSwitchMaskDestMacAddress(packetSwitchMask_t *mask, char *mac);
int settcamRegisterPacketSwitchMaskSrcMacAddress(packetSwitchMask_t *mask, char *mac);
int settcamRegisterPacketSwitchMaskDestIPAddress(packetSwitchMask_t *mask, char *ipaddr);
int settcamRegisterPacketSwitchMaskSrcIPAddress(packetSwitchMask_t *mask, char *ipaddr);
int settcamRegisterPacketSwitchMaskDestL4Port(packetSwitchMask_t *mask, uint16 port);
int settcamRegisterPacketSwitchMaskSrcL4Port(packetSwitchMask_t *mask, uint16 port);
int settcamRegisterPacketSwitchMaskVLANB(packetSwitchMask_t *mask, uint16 vlan);
int settcamRegisterPacketSwitchMaskVLANA(packetSwitchMask_t *mask, uint16 vlan);
int settcamRegisterPacketSwitchMaskEthType(packetSwitchMask_t *mask, uint16 ethType);
int settcamRegisterPacketSwitchMaskIPProtocol(packetSwitchMask_t *mask, uint8 ipProtocol);
int settcamRegisterPacketSwitchMaskMessageType(packetSwitchMask_t *mask, uint8 type);
int settcamRegisterPacketSwitchMaskFlagField(packetSwitchMask_t *mask, uint16 flag);

int settcamRegisterResult(tcamRegisterSet_t *tcamRegisterSet, uint32 result);
//int settcamRegisterMask(tcamRegisterSet_t *tcamRegisterSet, uint64 mask);
int settcamRegisterMatch(tcamRegisterSet_t *tcamRegisterSet, uint32 match);

void dumptcamRegisterPacketSwitchArray(uint32 *array, int num, const char *header);
void dumptcamRegisterSetMultiple(packetSwitch_t *packetSwitch, int port);
void dumptcamRegisterPacketSwitchKeyMultiple(packetSwitchKey_t *keys);
void *memcpy32(uint32_t *dest, const uint32_t *src, size_t count);
void dumpPacketSwitchDetails(packetSwitch_t* packetSwitch, int port);
void print_mac_address(const mac_address *macAddr, const char *header);
#ifdef DEBUG_REG_SUPPORT
int packetSwitchFlushAllTxCounters(packetSwitchTxDebugReg_t *tx);
int packetSwitchFlushAllRxCounters(packetSwitchRxDebugReg_t *rx);
#endif

uint32 getNumDMAPorts (packetSwitchGeneral_t *pGenstatus);
uint32 getNumHSSIPorts (packetSwitchGeneral_t *pGenstatus);
uint32 getNumUserPorts (packetSwitchGeneral_t *pGenstatus);
int readMacAddressPerIFace (const char *iface, char *mac);
int isEthernetPortValid(char *eth);
int validate_mac(mac_address *macAddr, const char *arg);

void bigEndianToLittleEndian_32(uint32_t *x);
void littleEndianToBigEndian_32(uint32_t *x);
void bigEndianToLittleEndian_16(uint16_t *x);
void littleEndianToBigEndian_16(uint16_t *x);
void bigEndianToLittleEndian_in6Addr(struct in6_addr *addr);
void littleEndianToBigEndian_in6Addr(struct in6_addr *addr);

#endif //__PACKET_SWITCH_REGISTER_INTERFACE_H__
