/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Switch Application v2.0                              **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include <dirent.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <stdint.h>
#include <netinet/in.h> // For struct in_addr and struct in6_addr
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include "packetswitchRegisterInterface.h"

/**
 * @brief Reads the MAC address for a given network interface.
 *
 * @param iface The name of the network interface.
 * @param The MAC address of the network interface as a string.
 * 
 * @return 0 on success, -1 on failure.
 */
int readMacAddressPerIFace (const char *iface, char *mac)
{
    int fd;
    struct ifreq ifr;

    memset(&ifr, 0, sizeof(ifr));

    fd = socket(AF_INET, SOCK_DGRAM, 0);

    if (fd < 0) {
	printf("Not able to open socket - %s\n", strerror(errno));
	return FAILURE;
    }

    ifr.ifr_addr.sa_family = AF_INET;
    strncpy(ifr.ifr_name , iface , IFNAMSIZ-1);

    if (0 == ioctl(fd, SIOCGIFHWADDR, &ifr)) {
	snprintf(mac, SIZEOF_MAC_ADDRESS, "%02x:%02x:%02x:%02x:%02x:%02x", 
			ifr.ifr_hwaddr.sa_data[0],ifr.ifr_hwaddr.sa_data[1],ifr.ifr_hwaddr.sa_data[2],
			ifr.ifr_hwaddr.sa_data[3],ifr.ifr_hwaddr.sa_data[4],ifr.ifr_hwaddr.sa_data[5]);

	printf("%s - %s\n", iface, mac);
    } else {
	printf("%s - error\n", __FUNCTION__);
    }

    close(fd);

    return 0;
}

/**
 * Reads the MAC addresses from a device.
 *
 * This function retrieves the MAC addresses of a device and returns them as a list.
 * The MAC addresses are unique identifiers assigned to network interfaces.
 *
 * @return A list of MAC addresses found on the device.
 */
int readMacAddresses(char **mac, int *num)
{
	DIR *dir_ptr;
	int i = 0;
	struct dirent *read_dir;
	dir_ptr = opendir("/sys/class/net/");
	//check if there is an error while opening
	if (dir_ptr == NULL) {
		perror("Can't open the file\n");
		return 1;
	}
	while ((read_dir = readdir(dir_ptr)) != NULL) {
		if (read_dir->d_type == DT_DIR) {
			if (strncmp(read_dir->d_name, "lo", 2) != 0) {
				readMacAddressPerIFace(read_dir->d_name, mac[i]);
				i++;
			}
		}
	}
	*num = i;
	//close the dir, and check if there are any errors
	if(closedir(dir_ptr) == -1) {
		perror("Can't close the dir\n");
		return 0;
	}
	return 1;
}

/**
 * Reads the number of valid ethernet devices
 *
 * This function retrieves the ethernet devices on the system and 
 * returns the number of valid ethernet devices.
 *
 * @return A list of ethernet devices.
 */
int isEthernetPortValid(char *eth)
{
	DIR *dir_ptr;
	bool found = false;
	struct dirent *read_dir;
	dir_ptr = opendir("/sys/class/net/");
	//check if there is an error while opening
	if (dir_ptr == NULL) {
		perror("Can't open the file\n");
		return FAILURE;
	}
	while ((read_dir = readdir(dir_ptr)) != NULL) {
		if (strncmp(read_dir->d_name, eth, strlen(read_dir->d_name)) == 0) {
			found = true;
			break;
		}
	}
	
	//close the dir, and check if there are any errors
	if(closedir(dir_ptr) == -1) {
		perror("Can't close the dir\n");
		return FAILURE;
	}
	if (found == true) {
		return SUCCESS;
	}
	return FAILURE;
}
