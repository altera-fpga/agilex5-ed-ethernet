/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Switch Application v2.0                              **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include "packetswitchRegisterMap.h"
#include "packetswitchRegisterInterface.h"
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>

#define DEBUG_COUNTER_CLEAR 0xFFFFFFFF

/*
 * PacketSwitch searches the TCAM in little endian format. The key values that 
 * are in the MAC header and IP header need to be populated in the TCAM in 
 * little endian format. This is because the HSSI subsystem also transforms these 
 * fields from network endian to little endian format. Hence if we are on a big endian
 * based system, we require these functions to do the endian management of the keys.
 *
 */

void bigEndianToLittleEndian_32(uint32_t *x) {
	*x = ((*x >> 24) & 0x000000FF) |
		((*x >> 8) & 0x0000FF00) |
		((*x << 8) & 0x00FF0000) |
		((*x << 24) & 0xFF000000);
}

void littleEndianToBigEndian_32(uint32_t *x) {
	*x = ((*x >> 24) & 0x000000FF) |
		((*x >> 8) & 0x0000FF00) |
		((*x << 8) & 0x00FF0000) |
		((*x << 24) & 0xFF000000);
}

void bigEndianToLittleEndian_16(uint16_t *x) {
	*x = ((*x >> 8) & 0x00FF) |
		((*x << 8) & 0xFF00);
}

void littleEndianToBigEndian_16(uint16_t *x) {
	*x = ((*x >> 8) & 0x00FF) |
		((*x << 8) & 0xFF00);
}

void bigEndianToLittleEndian_in6Addr(struct in6_addr *addr) {
	for (int i = 0; i < 8; i++) {
		// Each segment is 16 bits (2 bytes), so swap the bytes
		uint16_t *segment = (uint16_t *)&addr->s6_addr[i * 2];
		*segment = ((*segment >> 8) & 0x00FF) | ((*segment << 8) & 0xFF00);
	}
}

void littleEndianToBigEndian_in6Addr(struct in6_addr *addr) {
	for (int i = 0; i < 8; i++) {
		// Each segment is 16 bits (2 bytes), so swap the bytes
		uint16_t *segment = (uint16_t *)&addr->s6_addr[i * 2];
		*segment = ((*segment >> 8) & 0x00FF) | ((*segment << 8) & 0xFF00);
	}
}
void setIngressArbiterScratchReg(ingressArbiter_t *ingressArbiter, uint32 reg)
{
	ingressArbiter->scratchReg = reg;
}
/**
 * @brief Sets the value of the Ingress Arbiter DMA Config Priority.
 *
 * @param ingressArbiter Pointer to the ingressArbiter_t structure.
 * @param port The port number.
 * @param pri The value to set the DMA Config Priority to.
 * 
 * @return None.
 */
void setIngressArbiterDMAConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri)
{
	cfgPriority_t priority;
	priority.priorityVal = ingressArbiter->cfgPriorityDma.priorityVal;
	if (port %2 == 0) {
		priority.priority[port/2].ch0 = (pri & PACKET_SWITCH_INGRESS_ARBITER_PRI_MASK);
	} else {
		priority.priority[port/2].ch1 = (pri & PACKET_SWITCH_INGRESS_ARBITER_PRI_MASK);
	}
	ingressArbiter->cfgPriorityDma.priorityVal = priority.priorityVal;
}
/**
 * @brief Sets the value of the Ingress Arbiter User Config Priority register.
 *
 * @param ingressArbiter Pointer to the ingressArbiter_t structure.
 * @param port The port number.
 * @param pri The value to set the User Config Priority to.
 * 
 * @return None.
 */
void setIngressArbiterUserConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri)
{
	cfgPriority_t priority;
	priority.priorityVal = ingressArbiter->cfgPriorityUser.priorityVal;
	if (port %2 == 0) {
		priority.priority[port/2].ch0 = (pri & PACKET_SWITCH_INGRESS_ARBITER_PRI_MASK);
	} else {
		priority.priority[port/2].ch1 = (pri & PACKET_SWITCH_INGRESS_ARBITER_PRI_MASK);
	}
	ingressArbiter->cfgPriorityUser.priorityVal = priority.priorityVal;
}
/**
 * @brief Sets the value of the Egress RX Demux Scratch Register.
 *
 * @param egressRXDemux Pointer to the egressRXDemux_t structure.
 * @param port The port number.
 * @param reg The value to set the scratch register to.
 * 
 * @return None.
 */
void setEgressRXDemuxScratchReg(egressRXDemux_t *egressRXDemux, uint32 reg)
{
	egressRXDemux->scratchReg = reg;
}
/**
 * @brief Sets the value of the Egress RX Demux Drop enable status of the Control Register.
 *
 * @param egressRXDemux Pointer to the egressRXDemux_t structure.
 * @param port The port number.
 * @param enable Enable drop status
 * 
 * @return None.
 */
void setEgressRXDemuxDropConfig(egressRXDemux_t *egressRXDemux, uint32 port, bool enable)
{
	uint32 controlRegVal;
	controlRegVal = egressRXDemux->controlReg;
	if (enable) {
		controlRegVal |= (1 << port);
	} else {
		controlRegVal &= !(1 << port);
	}
	egressRXDemux->controlReg = controlRegVal;
}
/**
 * @brief Sets the value of the Egress RX Demux DMA0 Drop Threshold Register.
 *
 * @param egressRXDemux Pointer to the egressRXDemux_t structure.
 * @param port The port number.
 * @param reg The value to set the DMA0 Drop Threshold register to.
 * 
 * @return None.
 */
void setEgressRXDemuxDMADropThresholdReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg)
{
	if (port >=3) {
		printf("Port value greater than 2 not supported\n");
	}
	egressRXDemux->dmaDropThresholdReg[port] = reg;
}
/**
 * @brief Sets the value of the Ingress RX Width Adapter Scratch Register.
 *
 * @param ingressRXWidthAdapter Pointer to the ingressRXWidthAdapter_t structure.
 * @param port The port number.
 * @param reg The value to set the scratch register to.
 * 
 * @return None.
 */
void setIngressRXWidthAdapterScratchReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 reg)
{
	ingressRXWidthAdapter->scratchReg = reg;
}
/**
 * @brief Sets the value of RxPause enable bit in Ingress RX Width Adapter Control Register.
 *
 * @param ingressRXWidthAdapter Pointer to the ingressRXWidthAdapter_t structure.
 * @param enable The value to set the bit
 * 
 * @return None.
 */
void setIngressRXWidthAdapterRxPauseEnable(ingressRXWidthAdapter_t *ingressRXWidthAdapter, bool enable)
{
	ingressRXWidthAdapter->controlReg.control.rxPauseEnable = enable;
}
/**
 * @brief Sets the value of the Ingress RX Width Adapter CFG RxPause Threshold.
 *
 * @param ingressRXWidthAdapter Pointer to the ingressRXWidthAdapter_t structure.
 * @param threshold The value to set the CFG RXPause Threshold register to.
 * 
 * @return None.
 */
void setIngressRXWidthAdapterCfgRxPauseThresholdReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 threshold)
{
	ingressRXWidthAdapter->thresholdReg.threshold.rxPauseThreshold = threshold & 0xFFFF;
}
/**
 * @brief Sets the value of the Ingress RX Width Adapter CFG Drop Threshold Register.
 *
 * @param ingressRXWidthAdapter Pointer to the ingressRXWidthAdapter_t structure.
 * @param threshold The value to set the Threshold
 * 
 * @return None.
 */
void setIngressRXWidthAdapterCfgDropThresholdReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 threshold)
{
	ingressRXWidthAdapter->thresholdReg.threshold.dropThreshold = threshold & 0xFFFF;
}
/**
 * @brief Sets the value of the Egress RX Width Adapter Scratch Register.
 *
 * @param egressRXWidthAdapter Pointer to the egressRXWidthAdapter_t structure.
 * @param port The port number.
 * @param reg The value to set the scratch register to.
 * 
 * @return None.
 */
void setEgressRXWidthAdapterScratchReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 reg)
{
	egressRXWidthAdapter->scratchReg = reg;
}
/**
 * @brief Sets the value of the Egress RX Width Adapter Control Register.
 *
 * @param egressRXWidthAdapter Pointer to the egressRXWidthAdapter_t structure.
 * @param enable Drop enable or disable
 * 
 * @return None.
 */
void setEgressRXWidthAdapterControlDrop(egressRXWidthAdapter_t *egressRXWidthAdapter, bool enable)
{
	egressRXWidthAdapter->controlReg.control.dropEnable = enable;
}
/**
 * @brief Sets the value of the Egress RX Width Adapter CFG Drop Threshold Register.
 *
 * @param egressRXWidthAdapter Pointer to the egressRXWidthAdapter_t structure.
 * @param threshold The value to set the CFG Drop Threshold register to.
 * 
 * @return None.
 */
void setEgressRXWidthAdapterCfgDropThresholdReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 threshold)
{
	egressRXWidthAdapter->dropThresholdReg.threshold.dropThreshold = threshold & 0xFFFF;
}
/**
 * @brief Sets the value of the TCAM Register Scratch Register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param reg The value to set the scratch register to.
 * 
 * @return None.
 */
void settcamRegisterScratchReg(tcamRegisterSet_t *tcamRegisterSet, uint32 reg)
{
	tcamRegisterSet->scratch_reg = reg;
}
/**
 * @brief Checks if the TCAM General Control Init Done bit is set.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * 
 * @return SUCCESS if the bit is set, FAILURE otherwise.
 */
int checktcamGeneralControlInitDone(tcamRegisterSet_t *tcamRegisterSet)
{
	generalControl_t ctrl;
        ctrl.value = *(uint32*)(&(tcamRegisterSet->general_control));
	uint32 count = 0;
	while (!(GENERAL_CONTROL_INIT_DONE_GET(ctrl.gen_ctrl.init_done) & GENERAL_CONTROL_INIT_DONE_READY)) {
		sleep(1);
		count++;
		if (count > TCAM_INIT_MAX_WAIT_TIME) return FAILURE;
		ctrl.value = *(uint32*)(&(tcamRegisterSet->general_control));
	}
	return SUCCESS;
}
/**
 * @brief Waits till the TCAM Management Control Busy bit is cleared.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * 
 * @return None.
 */
void tcamMgmtControlWaitTillBusyDone(tcamRegisterSet_t *tcamRegisterSet)
{
	mgmtControl_t mgmt;
	mgmt.value = *(uint32*)(&(tcamRegisterSet->mgmt_control));
	while (MGMT_CONTROL_BUSY_GET(mgmt.mgmt_ctrl.busy) & MGMT_CONTROL_BUSY_POSITIVE) {
		sleep(1);
		mgmt.value = *(uint32*)(&(tcamRegisterSet->mgmt_control));
	}
	return;
}
/**
 * @brief Checks the result of the TCAM Management Control operation.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int tcamMgmtControlOperationResult(tcamRegisterSet_t *tcamRegisterSet)
{
	mgmtControl_t mgmt;
	mgmt.value = *(uint32*)(&(tcamRegisterSet->mgmt_control));
	if (MGMT_CONTROL_SUCCESS_GET(mgmt.mgmt_ctrl.success)==MGMT_CONTROL_SUCCESS_POSITIVE) {
		return SUCCESS;
	}
	return FAILURE;
}
/**
 * @brief Sets the TCAM Management Control Operation Type.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param opType The operation type to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int tcamMgmtControlSetOpType(tcamRegisterSet_t *tcamRegisterSet, uint32 opType)
{
	mgmtControl_t mgmt;
	//Wait till previous operation was done
	tcamMgmtControlWaitTillBusyDone(tcamRegisterSet);
	if (opType >= MGMT_CONTROL_OP_TYPE_MAX) {
		return FAILURE;
	}
        mgmt.value = *(uint32*)(&(tcamRegisterSet->mgmt_control));
	//Write the opType directly to the register
	mgmt.mgmt_ctrl.op_type = (opType & MGMT_CONTROL_OP_TYPE_MASK);
	*(uint32*)(&(tcamRegisterSet->mgmt_control)) = mgmt.value;
	return SUCCESS;
}
/**
 * @brief Sets the TCAM Key Entry register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param entry The entry value to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int tcamSetEntry(tcamRegisterSet_t *tcamRegisterSet, uint32 entry)
{
	tcamRegisterSet->entry = entry;
	return SUCCESS;
}
/**
 * @brief Reads and resets the TCAM Warning register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param warning Pointer to the warning value.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int tcamWarningReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *warning)
{
	*warning = tcamRegisterSet->warning;
	tcamRegisterSet->warning = 0xFFFFFFFF;
	return SUCCESS;
}
/**
 * @brief Reads and resets the TCAM Monitor register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param monitor Pointer to the monitor value.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int tcamMonitorReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *monitor)
{
	*monitor = tcamRegisterSet->monitor;
	tcamRegisterSet->monitor = 0xFFFFFFFF;
	return SUCCESS;
}
/**
 * @brief Registers the Destination MAC address in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param mac The MAC address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyDestMacAddress(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, char *mac)
{
	memcpy(&(pkey->key.dst_mac), mac, sizeof(mac_address));
	memset(&(mask->key.dst_mac), 0xFF, sizeof(mac_address));
	return SUCCESS;
}
/**
 * @brief Registers the Destination MAC address mask in the Packet Switch Mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param mac The MAC address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskDestMacAddress(packetSwitchMask_t *mask, char *mac)
{
	memcpy(&(mask->key.dst_mac), mac, sizeof(mac_address));
	return SUCCESS;
}

/**
 * @brief Registers the Source MAC address in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param mac The MAC address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeySrcMacAddress(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, char *mac)
{
	memcpy(&(pkey->key.src_mac), mac, sizeof(mac_address));
	memset(&(mask->key.src_mac), 0xFF, sizeof(mac_address));
	return SUCCESS;
}
/**
 * @brief Registers the source MAC address mask in the Packet Switch Mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param mac The MAC address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskSrcMacAddress(packetSwitchMask_t *mask, char *mac)
{
	memcpy(&(mask->key.src_mac), mac, sizeof(mac_address));
	return SUCCESS;
}
/**
 * @brief Registers the Destination IP address in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipaddr The IP address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyDestIPAddress(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, char *ipaddr)
{
	if (inet_pton(AF_INET, ipaddr, &(pkey->key.dst_ip.ipv4)) == 1) {
		memset(&(mask->key.dst_ip.ipv4), 0xFF, sizeof(struct in_addr));
		bigEndianToLittleEndian_32((uint32*)&(pkey->key.dst_ip.ipv4));
		return SUCCESS;
	} else if (inet_pton(AF_INET6, ipaddr, &(pkey->key.dst_ip.ipv6)) == 1) {
		memset(&(mask->key.dst_ip.ipv6), 0xFF, sizeof(struct in6_addr));
		bigEndianToLittleEndian_in6Addr(&(pkey->key.dst_ip.ipv6));
		return SUCCESS;
	}
	return FAILURE;
}
/**
 * @brief Registers the Destination IP address Mask in the Packet Switch Mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipaddr The IP address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskDestIPAddress(packetSwitchMask_t *mask, char *ipaddr)
{
	if (inet_pton(AF_INET, ipaddr, &(mask->key.dst_ip.ipv4)) == 1) {
		bigEndianToLittleEndian_32((uint32*)&(mask->key.dst_ip.ipv4));
		return SUCCESS;
	} else if (inet_pton(AF_INET6, ipaddr, &(mask->key.dst_ip.ipv6)) == 1) {
		bigEndianToLittleEndian_in6Addr(&(mask->key.dst_ip.ipv6));
		return SUCCESS;
	}
	return FAILURE;
}
/**
 * @brief Registers the Source IP address in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipaddr The IP address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeySrcIPAddress(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, char *ipaddr)
{
	if (inet_pton(AF_INET, ipaddr, &(pkey->key.src_ip.ipv4)) == 1) {
		bigEndianToLittleEndian_32((uint32*)&(pkey->key.src_ip.ipv4));
		memset(&(mask->key.src_ip.ipv4), 0xFF, sizeof(struct in_addr));
		return SUCCESS;
	} else if (inet_pton(AF_INET6, ipaddr, &(pkey->key.src_ip.ipv6)) == 1) {
		bigEndianToLittleEndian_in6Addr(&(pkey->key.src_ip.ipv6));
		memset(&(mask->key.src_ip.ipv6), 0xFF, sizeof(struct in6_addr));
		return SUCCESS;
	}
	return FAILURE;
}
/**
 * @brief Registers the Source IP address mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipaddr The IP address to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskSrcIPAddress(packetSwitchMask_t *mask, char *ipaddr)
{
	if (inet_pton(AF_INET, ipaddr, &(mask->key.src_ip.ipv4)) == 1) {
		bigEndianToLittleEndian_32((uint32*)&(mask->key.src_ip.ipv4));
		return SUCCESS;
	} else if (inet_pton(AF_INET6, ipaddr, &(mask->key.src_ip.ipv6)) == 1) {
		bigEndianToLittleEndian_in6Addr(&(mask->key.src_ip.ipv6));
		return SUCCESS;
	}
	return FAILURE;
}
/**
 * @brief Registers the Destination Layer 4 port in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param port The port number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyDestL4Port(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 port)
{
	pkey->key.l4_dst_port = port;
	mask->key.l4_dst_port = UINT16_MAX;
	return SUCCESS;
}
/**
 * @brief Registers the Destination Layer 4 port mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param port The port number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskDestL4Port(packetSwitchMask_t *mask, uint16 port)
{
	mask->key.l4_dst_port = port;
	return SUCCESS;
}
/**
 * @brief Registers the Source Layer 4 port in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param port The port number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeySrcL4Port(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 port)
{
	pkey->key.l4_src_port = port;
	mask->key.l4_src_port = UINT16_MAX;
	return SUCCESS;
}
/**
 * @brief Registers the source Layer 4 port mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param port The port number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskSrcL4Port(packetSwitchMask_t *mask, uint16 port)
{
	mask->key.l4_src_port = port;
	return SUCCESS;
}
/**
 * @brief Registers the VLAN B in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param vlan The VLAN number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyVLANB(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 vlan)
{
	pkey->key.tci_vlanb = vlan;
	mask->key.tci_vlanb = UINT16_MAX;
	return SUCCESS;
}
/**
 * @brief Registers the VLAN B mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param vlan The VLAN number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskVLANB(packetSwitchMask_t *mask, uint16 vlan)
{
	mask->key.tci_vlanb = vlan;
	return SUCCESS;
}
/**
 * @brief Registers the VLAN A in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param vlan The VLAN number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyVLANA(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 vlan)
{
	pkey->key.tci_vlana = vlan;
	mask->key.tci_vlana = UINT16_MAX;
	return SUCCESS;
}
/**
 * @brief Registers the VLAN A mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param vlan The VLAN number to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskVLANA(packetSwitchMask_t *mask, uint16 vlan)
{
	mask->key.tci_vlana = vlan;
	return SUCCESS;
}
/**
 * @brief Registers the Ethernet Type in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ethType The Ethernet Type to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyEthType(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 ethType)
{
	pkey->key.ethtype = ethType & PACKET_SWITCH_KEY_ETHTYPE_MASK;
	mask->key.ethtype = UINT16_MAX & PACKET_SWITCH_KEY_ETHTYPE_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the Ethernet Type mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ethType The Ethernet Type to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskEthType(packetSwitchMask_t *mask, uint16 ethType)
{
	mask->key.ethtype = ethType & PACKET_SWITCH_KEY_ETHTYPE_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the IP Protocol in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipProtocol The IP Protocol to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyIPProtocol(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint8 ipProtocol)
{
	pkey->key.ip_protocol = ipProtocol & PACKET_SWITCH_KEY_IP_PROTOCOL_MASK;
	mask->key.ip_protocol = UINT8_MAX & PACKET_SWITCH_KEY_IP_PROTOCOL_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the IP Protocol mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param ipProtocol The IP Protocol to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskIPProtocol(packetSwitchMask_t *mask, uint8 ipProtocol)
{
	mask->key.ip_protocol = ipProtocol & PACKET_SWITCH_KEY_IP_PROTOCOL_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the Message Type in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param type The Message Type to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyMessageType(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint8 type)
{
	pkey->key.messageType = type & PACKET_SWITCH_KEY_MESSAGE_TYPE_MASK;
	mask->key.messageType = UINT8_MAX & PACKET_SWITCH_KEY_MESSAGE_TYPE_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the Message Type mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param type The Message Type to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskMessageType(packetSwitchMask_t *mask, uint8 type)
{
	mask->key.messageType = type & PACKET_SWITCH_KEY_MESSAGE_TYPE_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the Flag Field in the Packet Switch Key.
 *
 * @param pkey Pointer to the packetSwitchKey_t structure.
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param flag The Flag Field to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchKeyFlagField(packetSwitchKey_t *pkey, packetSwitchMask_t *mask, uint16 flag)
{
	pkey->key.flagField_low = pkey->key.flagField_high = 0;
	pkey->key.flagField_low |=flag & PACKET_SWITCH_KEY_FLAG_FIELD_LOW_MASK;
	pkey->key.flagField_high |= (flag>>0x4) & (PACKET_SWITCH_KEY_FLAG_FIELD_HIGH_MASK);
	mask->key.flagField_low = UINT8_MAX & PACKET_SWITCH_KEY_FLAG_FIELD_LOW_MASK;
	mask->key.flagField_high = UINT16_MAX & PACKET_SWITCH_KEY_FLAG_FIELD_HIGH_MASK;
	return SUCCESS;
}
/**
 * @brief Registers the Flag Field mask in the Packet Switch mask.
 *
 * @param mask Pointer to the packetSwitchMask_t structure.
 * @param flag The Flag Field to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterPacketSwitchMaskFlagField(packetSwitchMask_t *mask, uint16 flag)
{
	mask->key.flagField_low = mask->key.flagField_high = 0;
	mask->key.flagField_low |=flag & PACKET_SWITCH_KEY_FLAG_FIELD_LOW_MASK;
	mask->key.flagField_high |= (flag>>0x4) & (PACKET_SWITCH_KEY_FLAG_FIELD_HIGH_MASK);
	return SUCCESS;
}
/**
 * @brief Sets the Result Register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param result The result to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterResult(tcamRegisterSet_t *tcamRegisterSet, uint32 result)
{
	tcamRegisterSet->result[0] = result;
	return SUCCESS;
}
#if 0
int settcamRegisterMask(tcamRegisterSet_t *tcamRegisterSet, uint64 mask)
{
	tcamRegisterSet->mask[0] = mask && 0xFFFFFFFF;
	tcamRegisterSet->mask[1] = (mask>>32) && 0xFFFFFFFF;
	return SUCCESS;
}
#endif
/**
 * @brief Sets the Match Register.
 *
 * @param tcamRegisterSet Pointer to the tcamRegisterSet_t structure.
 * @param match The match to set.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int settcamRegisterMatch(tcamRegisterSet_t *tcamRegisterSet, uint32 match)
{
	tcamRegisterSet->match[0] = match & 0xFFFFFFFF;
	return SUCCESS;
}
#ifdef DEBUG_REG_SUPPORT
/**
 * @brief Flushes all the TX debug counters of the Packet Switch.
 *
 * @param tx Pointer to the Tx debug register structure.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int packetSwitchFlushAllTxCounters(packetSwitchTxDebugReg_t *tx)
{
	uint32 i = 0;
	for (i=0; i<(sizeof(packetSwitchTxDebugReg_t)/sizeof(uint32)); i++) {
		//printf("Ptr: 0x%p I: %d Val: 0x%x\n", &(tx->values[i]), i, tx->values[i]);
		tx->values[i] = DEBUG_COUNTER_CLEAR;
		sleep(0);
	}
	return SUCCESS;
}
/**
 * @brief Flushes all the RX debug counters of the Packet Switch.
 *
 * @param rx Pointer to the Rx debug register structure.
 * 
 * @return SUCCESS if the operation was successful, FAILURE otherwise.
 */
int packetSwitchFlushAllRxCounters(packetSwitchRxDebugReg_t *rx)
{
	uint32 i = 0;
	for (i=0; i<(sizeof(packetSwitchRxDebugReg_t)/sizeof(uint32)); i++) {
		//printf("Ptr: 0x%p I: %d Val: %x\n", &(rx->values[i]), i, rx->values[i]);
		rx->values[i] = DEBUG_COUNTER_CLEAR;
		sleep(0);
	}
	return SUCCESS;
}

#endif

/**
 * @brief Validates a MAC address.
 * 
 * Validates a MAC address as to whether it complies to the standard notation or not
 *
 * @param mac The MAC address to validate. It can also contain the
 * 		  interface name to read the MAC address from.
 * 
 * @return True if the MAC address is valid, false otherwise.
 */
int validate_mac(mac_address *macAddr, const char *arg) {
	mac_address addr;
	addr.val.high = addr.val.low = 0;
	char mac[SIZEOF_MAC_ADDRESS];
	memset(mac, 0, SIZEOF_MAC_ADDRESS);
	if (strncmp(arg,"eth", 3) == 0) {
		readMacAddressPerIFace(arg, mac);	
	} else {
		strncpy(mac,arg, SIZEOF_MAC_ADDRESS-1);
	}

	if (sscanf(mac, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
				(unsigned char *)&(addr.mac.byte_0), (unsigned char *)&(addr.mac.byte_1), (unsigned char *)&(addr.mac.byte_2),
				(unsigned char *)&(addr.mac.byte_3), (unsigned char *)&(addr.mac.byte_4), (unsigned char *)&(addr.mac.byte_5)) == 6) {
		/*printf("%s:%d Mac: 0x%x 0x%x %02x:%02x:%02x:%02x:%02x:%02x\n", __FUNCTION__,__LINE__, addr.val.high, addr.val.low,
		  (unsigned int)(addr.mac.byte_0), (unsigned int)(addr.mac.byte_1), (unsigned int)(addr.mac.byte_2),
		  (unsigned int)(addr.mac.byte_3), (unsigned int)(addr.mac.byte_4), (unsigned int)(addr.mac.byte_5));
		  */
		macAddr->val.high = addr.val.high;
		macAddr->val.low = addr.val.low;
		return 1;
	} else {
		fprintf(stderr, "Invalid MAC address: %s\n", mac);
		return 0;
	}
}

uint32 getNumDMAPorts (packetSwitchGeneral_t *pGenstatus)
{
	packetSwitchGeneral_t genStatus;
	memcpy32((uint32*)(&genStatus), (uint32*)(pGenstatus), sizeof (packetSwitchGeneral_t)/4);
	return genStatus.generalReg.statusReg.status.dmaPorts;
}
uint32 getNumHSSIPorts (packetSwitchGeneral_t *pGenstatus)
{
	packetSwitchGeneral_t genStatus;
	memcpy32((uint32*)(&genStatus), (uint32*)(pGenstatus), sizeof (packetSwitchGeneral_t)/4);
	return genStatus.generalReg.statusReg.status.hssiUserPorts;
}
uint32 getNumUserPorts (packetSwitchGeneral_t *pGenstatus)
{
	packetSwitchGeneral_t genStatus;
	memcpy32((uint32*)(&genStatus), (uint32*)(pGenstatus), sizeof (packetSwitchGeneral_t)/4);
	return genStatus.generalReg.statusReg.status.userPorts;
}
