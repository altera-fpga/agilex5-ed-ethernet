/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Switch Application v2.0                              **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#ifndef __PACKET_SWITCH_REISTER_MAP_H__
#define __PACKET_SWITCH_REISTER_MAP_H__

#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <netinet/in.h> // For struct in_addr and struct in6_addr
#include <arpa/inet.h>  // For inet_pton and inet_ntop

#define MAX_NUM_PORTS_SUPPORTED 2
#define MAX_NUM_DMA_PORTS_SUPPORTED 8
#define MAX_NUM_USER_PORTS_SUPPORTED 8

#define SUCCESS	0
#define FAILURE	(-1)

typedef uint64_t uint64;
typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uint8_t uint8;

#pragma pack(push, 1)
#define PACKET_SWITCH_INGRESS_ARBITER_PRI_MASK	0xF
typedef union {
	uint32 priorityVal;
	struct {
		uint32 ch0:4;
		uint32 ch1:4;
	} priority[MAX_NUM_DMA_PORTS_SUPPORTED/2];
}cfgPriority_t;
typedef struct ingressArbiter {
	uint32 scratchReg;
	cfgPriority_t cfgPriorityDma;
	cfgPriority_t cfgPriorityUser;
} ingressArbiter_t;


typedef struct egressRXDemux {
	uint32 scratchReg;
	uint32 controlReg;
	uint32 dmaDropThresholdReg[MAX_NUM_DMA_PORTS_SUPPORTED];
} egressRXDemux_t;

typedef struct ingressRXWidthAdapter {
	uint32 scratchReg;
	union {
		uint32 controlRegVal;
		struct {
			uint32 rxPauseEnable:1;
		} control;
	} controlReg;
	union {
		uint32 thresholdRegVal;
		struct {
			uint32 rxPauseThreshold:16;
			uint32 dropThreshold:16;
		} threshold;
	} thresholdReg;
} ingressRXWidthAdapter_t;

typedef struct egressRXWidthAdapter {
	uint32 scratchReg;
	union {
		uint32 controlRegVal;
		struct {
			uint32 dropEnable:1;
		} control;
	} controlReg;
	union {
		uint32 dropThresholdRegVal;
		struct {
			uint32 dropThreshold:16;
		} threshold;
	} dropThresholdReg;
} egressRXWidthAdapter_t;

typedef union {
	uint8 arr[6];
	struct {
		uint32 low;
		uint16 high;
	} val;
	struct {
		uint8 byte_5;
		uint8 byte_4;
		uint8 byte_3;
		uint8 byte_2;
		uint8 byte_1;
		uint8 byte_0;
	} mac;
} mac_address;

#define SIZE_OF_IPV4_ADDRESS	sizeof(struct in_addr)
typedef union {
    struct in_addr ipv4;  // IPv4 address structure
    struct in6_addr ipv6; // IPv6 address structure
} ip_address;
#pragma pack(pop)

#define PACKET_SWITCH_KEY_ETHTYPE_MASK		0xFFFF
#define PACKET_SWITCH_KEY_ETHTYPE_GET(x)		((x)&PACKET_SWITCH_KEY_ETHTYPE_MASK)
#define PACKET_SWITCH_KEY_IP_PROTOCOL_MASK		0xFF
#define PACKET_SWITCH_KEY_IP_PROTOCOL_GET(x)	((x)&PACKET_SWITCH_KEY_IP_PROTOCOL_MASK)
#define PACKET_SWITCH_KEY_MESSAGE_TYPE_MASK	0xF
#define PACKET_SWITCH_KEY_MESSAGE_TYPE_GET(x)	((x)&PACKET_SWITCH_KEY_MESSAGE_TYPE_MASK)
#define PACKET_SWITCH_KEY_FLAG_FIELD_LOW_MASK	0xF
#define PACKET_SWITCH_KEY_FLAG_FIELD_HIGH_MASK     0xFFF

#pragma pack(push, 1)
typedef union {
	uint32 keys[16];
	struct {
		mac_address dst_mac;
		mac_address src_mac;
		ip_address dst_ip;
		ip_address src_ip;
		uint16 l4_dst_port;
		uint16 l4_src_port;
		uint16 tci_vlanb;
		uint16 tci_vlana;
		uint32 ethtype:16;
		uint32 ip_protocol:8;
		uint32 messageType:4;
		uint32 flagField_low: 4;
		uint32 flagField_high:12;
		uint32 reserved_0:20;
		uint8 reserved[4];
	} key;
}packetSwitchKey_t;

#define PACKET_SWITCH_DEST_MAC_MASK	(0xFFFFFFFF)
#define PACKET_SWITCH_SRC_MAC_MASK		(0xFFFFFFFF << 48)


typedef union {
	uint32 masks[16];
	struct {
                 mac_address dst_mac;
                 mac_address src_mac;
                 ip_address dst_ip;
                 ip_address src_ip;
                 uint16 l4_dst_port;
                 uint16 l4_src_port;
                 uint16 tci_vlanb;
                 uint16 tci_vlana;
                 uint32 ethtype:16;
                 uint32 ip_protocol:8;
                 uint32 messageType:4;
                 uint32 flagField_low: 4;
                 uint32 flagField_high:12;
                 uint32 reserved_0:20;
                 uint8 reserved[4];
         } key;
} packetSwitchMask_t;
#pragma pack(pop)

//Version
#define TCAM_VERSION_MASK 0x0F

//TCAM FeatureList
#define FEATURE_LIST_AXI4_INTERFACE_SUPPORT 0x0
#define FEATURE_LIST_LOOK_UP_TYPE_SHIFT 16
#define FEATURE_LIST_LOOK_UP_TYPE_MASK	0xFF
#define FEATURE_LIST_LOOK_UP_TYPE_PPBB_EM_MBL_MASK 0x4
#define FEATURE_LIST_LOOK_UP_TYPE_PPBB_MS_TCAM_MASK 0x2
#define FEATURE_LIST_LOOK_UP_TYPE_PPBB_MC_BCAM_MASK 0x1
#define FEATURE_LIST_LOOK_UP_TYPE_GET(x)	((x)&FEATURE_LIST_LOOK_UP_TYPE_MASK)
#define FEATURE_LIST_LOOK_UP_TYPE_GETi(x)	(((x)>>FEATURE_LIST_LOOK_UP_TYPE_SHIFT)&FEATURE_LIST_LOOK_UP_TYPE_MASK)
#define IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_EM_MBL(x)	(FEATURE_LIST_LOOK_UP_TYPE_GET(x) & FEATURE_LIST_LOOK_UP_TYPE_PPBB_EM_MBL_MASK)
#define IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_MS_TCAM(x)	(FEATURE_LIST_LOOK_UP_TYPE_GET(x) & FEATURE_LIST_LOOK_UP_TYPE_PPBB_MS_TCAM_MASK)
#define IS_FEATURE_LIST_LOOK_UP_TYPE_PPBB_MC_BCAM(x)	(FEATURE_LIST_LOOK_UP_TYPE_GET(x) & FEATURE_LIST_LOOK_UP_TYPE_PPBB_MC_BCAM_MASK)
#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 interface_support:1;
		uint32 reserved_0:15;
		uint32 look_up_type:8;
		uint32 reserved_1:8;

	} feature;
} featureList_t;
#pragma pack(pop)

//TCAM Interface attribute parameters
#define INTERFACE_ATTRIBUTES_AXI_ST_READY_LATENCY_MASK 0xF
#define INTERFACE_ATTRIBUTES_AXI_ST_READY_LATENCY_MASK_GET(x)	((x)&INTERFACE_ATTRIBUTES_AXI_ST_READY_LATENCY_MASK)
#define INTERFACE_ATTRIBUTES_AXILITE_DATA_WIDTH_32BIT	0
#define INTERFACE_ATTRIBUTES_AXILITE_DATA_WIDTH_64BIT	1
#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 ready_latency:4;
		uint32 axilite_data_width:1;
		uint32 reserved_0:27;

	} attribute;
} interfaceAttributes_t;
#pragma pack(pop)

//TCAM General Control register
#define GENERAL_CONTROL_INIT_DONE_MASK	0x1
#define GENERAL_CONTROL_INIT_DONE_SHIFT	31
#define GENERAL_CONTROL_INIT_DONE_GET(x)	((x)&GENERAL_CONTROL_INIT_DONE_MASK)
#define GENERAL_CONTROL_INIT_DONE_NOT_DONE	0x0
#define GENERAL_CONTROL_INIT_DONE_READY		0x1
#define TCAM_INIT_MAX_WAIT_TIME		30 //arbitary wait time for init to complete - 30 sec
#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 reserved:31;
		uint32 init_done:1;
	} gen_ctrl;
} generalControl_t;
#pragma pack(pop)

//TCAM Management control register
#define MGMT_CONTROL_OP_TYPE_MASK 0x7
#define MGMT_CONTROL_OP_TYPE_GET(x) ((x)&MGMT_CONTROL_OP_TYPE_MASK)
#define MGMT_CONTROL_OP_TYPE_FLUSH 				0x0
#define MGMT_CONTROL_OP_TYPE_INSERT_ENTRY			0x1
#define MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_ENTRYID		0x2
#define MGMT_CONTROL_OP_TYPE_SEARCH_ENTRY			0x3
#define MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_KEY		0x4
#define MGMT_CONTROL_OP_TYPE_MAX				0x5
#define MGMT_CONTROL_SUCCESS_MASK 	0x1
#define MGMT_CONTROL_SUCCESS_GET(x) ((x)&MGMT_CONTROL_SUCCESS_MASK)
#define MGMT_CONTROL_SUCCESS_POSITIVE	0x1
#define MGMT_CONTROL_SUCCESS_NEGATIVE	0x0
#define MGMT_CONTROL_BUSY_MASK 0x1
#define MGMT_CONTROL_BUSY_GET(x) ((x)&MGMT_CONTROL_BUSY_MASK)
#define MGMT_CONTROL_BUSY_POSITIVE	0x1
#define MGMT_CONTROL_BUSY_NEGATIVE	0x0
#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 op_type:3;
		uint32 reserved_0:5;
		uint32 success:1;
		uint32 reserved_1:22;
		uint32 busy:1;
	} mgmt_ctrl;
} mgmtControl_t;
#pragma pack(pop)

//TCAM Warning
#define WARNING_UNSUPPORTED_CPU_SPACE	0x8000
#define WARNING_ENTRY_OUT_OF_RANGE	0x0020
#define WARNING_UNSUPPORTED_OP_TYPE	0x0010

//TCAM FATAL Errors
#define FATAL_ERROR_MGMT_INTF_INVALID_OPCODE	0x02
#define FATAL_ERROR_REQUEST_FIFO_FULL		0x04
/*TCAM Registers*/
#define MAX_TCAM_KEYS_SUPPORTED	64
#define MAX_TCAM_RESULT_REG	0x1F
#define MAX_TCAM_MASK_REG	0x1F
#define MAX_TCAM_MATCH_REG	0x1F
#pragma pack(push, 1)
typedef struct tcamRegisterSet_s {
	uint32 version;				//Offset 0x0
	uint32 scratch_reg;			//Offset 0x4
	featureList_t feature_list;		//Offset 0x8
	interfaceAttributes_t attr;		//Offset 0xC
	uint32 reserved_1[2];		
	generalControl_t general_control;	//Offset 0x18
	uint32 reserved_3;
	mgmtControl_t mgmt_control;		//Offset 0x20
	uint32 reserved_4[3];
	uint32 entry;				//Offset 0x30
	uint32 reserved_5[3];
	uint32 warning;				//Offset 0x40
	uint32 reserved_6[3];
	uint32 fatal_error;			//Offset 0x50
	uint32 reserved_7[3];
	uint32 monitor;				//Offset 0x60
	uint32 reserved_8[999];
	packetSwitchKey_t key;			//Offset 0x01000
	uint32 reserved_9[1008];
	uint32 result[MAX_TCAM_RESULT_REG];	//Offset 0x02000 
	uint32 reserved_10[0x1E1];
	uint32 match[MAX_TCAM_MATCH_REG];	//Offset 0x02800
	uint32 reserved_11[0x1E1];
	packetSwitchMask_t mask;			//Offset 0x03000
	uint32 reserved_13[0x3F0];
} tcamRegisterSet_t;

#ifdef DEBUG_REG_SUPPORT
typedef union {
	uint32 values[16];
	struct {
		uint32 hssi2iwadj_stats_reg;
		uint32 iwadj2pars_stats_reg;
		uint32 pars2lkup_stats_reg;
		uint32 lkup_drop_stats_reg;
		uint32 lkup2ewadj_user_stats_reg;
		uint32 ewadj2user_stats_reg;
		uint32 ewadj_user_drop_stats_reg;
		uint32 lkup2ewadj_dma_stats_reg;
		uint32 ewadj2dmux_dma_stats_reg;
		uint32 dmux_dma_0_drop_stats_reg;
		uint32 dmux_dma_1_drop_stats_reg;
		uint32 dmux_dma_2_drop_stats_reg;
		uint32 dmux2dma_0_stats_reg;
		uint32 dmux2dma_1_stats_reg;
		uint32 dmux2dma_2_stats_reg;
		uint32 rx_iwadj_drop_stats_reg;
	} rxDebugReg;
} packetSwitchRxDebugReg_t;

typedef union {
	uint32 values[8];
	struct {
		uint32  dma2iwadj_ch0_stats_reg;
		uint32 dma2iwadj_ch1_stats_reg;
		uint32 dma2iwadj_ch2_stats_reg;
		uint32 iwadj2iarb_ch0_stats_reg;
		uint32 iwadj2iarb_ch1_stats_reg;
		uint32 iwadj2iarb_ch2_stats_reg;
		uint32 user2iarb_stats_reg;
		uint32 iarb2hssi_stats_reg;
	} txDebugReg;
} packetSwitchTxDebugReg_t;
#endif

typedef union {
	uint32 values[5];
	struct {
		uint32 scratchReg;
		union {
			uint32 statusReg_val;
			struct {
				uint32 majorVersion:4;
				uint32 minorVersion:4;
				uint32 hssiUserPorts:4;
				uint32 dmaPorts:4;
				uint32 userPorts:4;
				uint32 dbgCntrEnable:1;
				uint32 rxInitDone:1;
				uint32 txInitDone:1;
				uint32 reserved:9;
			} status;
		} statusReg;
		uint32 reserved_0;
		uint32 reserved_1;
		uint32 reserved_2;
	} generalReg;
} packetSwitchGeneral_t;

typedef struct {
	ingressArbiter_t ingressArbiter;
	egressRXDemux_t egressRXDemux;
	ingressRXWidthAdapter_t ingressRXWidthAdapter;
	egressRXWidthAdapter_t egressRXWidthAdapter;
	uint8 reserved_0[0x74];
	tcamRegisterSet_t tcam;
	uint8 reserved_1[0x40];
} packetSwitchPort_t;

typedef struct {
	packetSwitchGeneral_t generalStatus;
	uint32 reserved[11];
	packetSwitchPort_t port[MAX_NUM_PORTS_SUPPORTED];
} packetSwitch_t;
#pragma pack(pop)

#endif //__PACKET_SWITCH_REISTER_MAP_H__
