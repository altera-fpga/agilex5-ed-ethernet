# PacketSwitch
Packet Switch application to configure and setup the PacketSwitch IP used in Ethernet and PTP System example designs

This application helps configure the PacketSwitch IP which provides ingress QOS functionalities and routes packets
to the network stack runing on the HPS or other entities connected through the user ports. This application
has been tested on the ARM based HPS of the Altera FPGA and is intended to be run only in that environment. Usgae
of this application else where could be done at your own risk.

The applictaion is pretty easy to configure and make. If you have all the shell environmen variables setup, 
please use autoconf utilities to make the package.

$ autoconf
$ ./configure
$ make all
$ make install

Usually, if you have the cross compilers setup and want to make the application only then use the specific compiler
to generate the application directly

Download toolchain from https://developer.arm.com/-/media/Files/downloads/gnu/11.3.rel1/binrel/arm-gnu-toolchain-11.3.rel1-x86_64-aarch64-none-linux-gnu.tar.xz
extract it,
 
$ export ARCH=arm64;
$ export CROSS_COMPILE=`pwd`/arm-gnu-toolchain-11.3.rel1-x86_64-aarch64-none-linux-gnu/bin/aarch64-none-linux-gnu-
$ cd ${working directory}
$ git clone https://github.com/intel-innersource/applications.fpga.hps.packetswitch
$ cd applications.fpga.hps.packetswitch
$ aarch64-none-linux-gnu-gcc *.c -o packetswitch

Look out for the help menu ("$packetswitch --help") to check for usage of the application
